WASD - Move around
F - Kill deer
T - Switch on car lights
Y - Switch off car lights
F - Light Campfire
Esc - Leave game