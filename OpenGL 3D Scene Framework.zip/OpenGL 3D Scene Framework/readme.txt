done by mohammad alwin

included:
-hella movement (WASD w/ direction, space for up, ctrl for down, shift for The Fast)
-FPS Camera
-skybok
-room for modelz
-text!
