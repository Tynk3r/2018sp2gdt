#include "Camera4.h"
#include "Application.h"
#include "Mtx44.h"

Camera4::Camera4()
{
}

Camera4::~Camera4()
{
}

void Camera4::Init(const Vector3& pos, const Vector3& target, const Vector3& up)
{
	this->position = defaultPosition = pos;
	this->target = defaultTarget = target;
	Vector3 view = (target - position).Normalized();
	Vector3 right = view.Cross(up);
	right.y = 0;
	right.Normalize();
	this->up = defaultUp = right.Cross(view).Normalized();
}

void Camera4::Update(double dt)
{
	if (currentMode == DRIVING)
	{
		static const float CAMERA_SPEED = 20.f;

		if (Application::IsKeyPressed(VK_LEFT) || Application::IsKeyPressed('A'))
		{
			//Edited for FPS
			float yaw = (float)(CAMERA_SPEED * dt);
			Vector3 view = (target - position).Normalized();
			Vector3 right = view.Cross(up);
			right.y = 0;
			right.Normalize();
			up = right.Cross(view).Normalized();

			Mtx44 rotation;
			rotation.SetToRotation(yaw, up.x, up.y, up.z);

			//new stuff

			view = rotation *view;
			target = position + view;
		}
		if (Application::IsKeyPressed(VK_RIGHT) || Application::IsKeyPressed('D'))
		{
			//Edited for FPS
			float yaw = (float)(-CAMERA_SPEED * dt);
			Vector3 view = (target - position).Normalized();
			Vector3 right = view.Cross(up);
			right.y = 0;
			right.Normalize();
			up = right.Cross(view).Normalized();

			Mtx44 rotation;
			rotation.SetToRotation(yaw, up.x, up.y, up.z);

			//new stuff

			view = rotation *view;
			target = position + view;
		}
		if (Application::IsKeyPressed(VK_UP) || Application::IsKeyPressed('W'))
		{
			float pitch = (float)(CAMERA_SPEED * dt);
			Vector3 view = (target - position).Normalized();
			Vector3 right = view.Cross(up);
			right.y = 0;
			right.Normalize();
			up = right.Cross(view).Normalized();

			Mtx44 rotation;
			rotation.SetToRotation(pitch, up.x, up.y, up.z);

			//new stuff

			view = rotation *view;
			target = position + view;
		}
		if (Application::IsKeyPressed(VK_DOWN) || Application::IsKeyPressed('S'))
		{
			float pitch = (float)(CAMERA_SPEED * dt);
			Vector3 view = (target - position).Normalized();
			Vector3 right = view.Cross(up);
			right.y = 0;
			right.Normalize();
			up = right.Cross(view).Normalized();
			Mtx44 rotation;
			rotation.SetToRotation(pitch, right.x, right.y, right.z);
			position = rotation * position;
		}
	}
	else if (currentMode == WALKING)
	{
		static const float CAMERA_SPEED = 30.f;

		rotateAngle = 70 * dt;

		if (Application::IsKeyPressed(VK_LEFT) || Application::IsKeyPressed('A'))
		{
			Vector3 view = (target - position).Normalized();
			Vector3 right = view.Cross(up);
			position = position - right;
			if (position.x < -450)
			{
				position.x = -450;
			}
			if (position.x > 450)
			{
				position.x = 450;
			}
			if (position.z < -450)
			{
				position.z = -450;
			}
			if (position.z > 450)
			{
				position.z = 450;
			}
			if (position.y > 450)
			{
				position.y = 450;
			}
			if (position.y < -450)
			{
				position.y = -450;
			}
			target = position + view;
		}
		if (Application::IsKeyPressed(VK_RIGHT) || Application::IsKeyPressed('D'))
		{
			Vector3 view = (target - position).Normalized();
			Vector3 right = view.Cross(up);
			position = position + right;
			if (position.x < -450)
			{
				position.x = -450;
			}
			if (position.x > 450)
			{
				position.x = 450;
			}
			if (position.z < -450)
			{
				position.z = -450;
			}
			if (position.z > 450)
			{
				position.z = 450;
			}
			if (position.y > 450)
			{
				position.y = 450;
			}
			if (position.y < -450)
			{
				position.y = -450;
			}
			target = position + view;
		}
		if (Application::IsKeyPressed(VK_UP) || Application::IsKeyPressed('W'))
		{
			Vector3 view = (target - position).Normalized();
			Vector3 right = view.Cross(up);
			position = position + view;
			if (position.x < -450)
			{
				position.x = -450;
			}
			if (position.x > 450)
			{
				position.x = 450;
			}
			if (position.z < -450)
			{
				position.z = -450;
			}
			if (position.z > 450)
			{
				position.z = 450;
			}
			if (position.y > 450)
			{
				position.y = 450;
			}
			if (position.y < -450)
			{
				position.y = -450;
			}
			target = position + view;
		}
		if (Application::IsKeyPressed(VK_DOWN) || Application::IsKeyPressed('S'))
		{
			Vector3 view = (target - position).Normalized();
			Vector3 right = view.Cross(up);
			position = position - view;
			if (position.x < -450)
			{
				position.x = -450;
			}
			if (position.x > 450)
			{
				position.x = 450;
			}
			if (position.z < -450)
			{
				position.z = -450;
			}
			if (position.z > 450)
			{
				position.z = 450;
			}
			if (position.y > 450)
			{
				position.y = 450;
			}
			if (position.y < -450)
			{
				position.y = -450;
			}
			target = position + view;
		}

		if (Application::getMouseXright() == 1)
		{
			Mtx44 rotation;
			Vector3 view = (target - position).Normalized();
			rotation.SetToRotation(-rotateAngle, 0, 1, 0);
			view = rotation * view;
			target = position + view;
		}

		if (Application::getMouseXleft() == 2)
		{
			Mtx44 rotation;
			Vector3 view = (target - position).Normalized();
			rotation.SetToRotation(rotateAngle, 0, 1, 0);
			view = rotation * view;
			target = position + view;
		}

		if (Application::getMouseYup() == 3)
		{
			Mtx44 rotation;
			Vector3 view = (target - position).Normalized();
			rotation.SetToRotation(-rotateAngle, 1, 0, 0);
			view = rotation * view;
			target = position + view;
		}

		if (Application::getMouseYdown() == 4)
		{
			Mtx44 rotation;
			Vector3 view = (target - position).Normalized();
			rotation.SetToRotation(rotateAngle, 1, 0, 0);
			view = rotation * view;
			target = position + view;
		}
	}

	if (Application::IsKeyPressed('R'))
	{
		Reset();
		currentMode = WALKING;
	}
	if (Application::IsKeyPressed('X'))
	{
		if (currentMode == WALKING)
		{
			currentMode = DRIVING;
		}
		else
		{
			currentMode = WALKING;
		}
	}
}

void Camera4::ChangeMode(Camera_Mode mode)
{
	currentMode = mode;
}

void Camera4::Reset()
{
	position = defaultPosition;
	target = defaultTarget;
	up = defaultUp;
	currentMode = WALKING;
}