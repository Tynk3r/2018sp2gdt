#include "MeshBuilder.h"
#include <GL\glew.h>
#include <vector>
#include "Vertex.h"
#include "LoadOBJ.h"

/******************************************************************************/
/*!
\brief
Generate the vertices of a reference Axes; Use red for x-axis, green for y-axis, blue for z-axis
Then generate the VBO/IBO and store them in Mesh object

\param meshName - name of mesh
\param lengthX - x-axis should start at -lengthX / 2 and end at lengthX / 2
\param lengthY - y-axis should start at -lengthY / 2 and end at lengthY / 2
\param lengthZ - z-axis should start at -lengthZ / 2 and end at lengthZ / 2

\return Pointer to mesh storing VBO/IBO of reference axes
*/
/******************************************************************************/
Mesh* MeshBuilder::GenerateAxes(const std::string &meshName, float lengthX, float lengthY, float lengthZ)
{
	std::vector<Vertex> vertexBuffer;
	std::vector<GLuint> indexBuffer;

	Vertex v;
	
	v.pos.Set(-lengthX, 0, 0);
	v.color.Set(1, 0, 0);
	vertexBuffer.push_back(v);

	v.pos.Set(lengthX, 0, 0);
	v.color.Set(1, 0, 0);
	vertexBuffer.push_back(v);

	v.pos.Set(0, -lengthY, 0);
	v.color.Set(0, 1, 0);
	vertexBuffer.push_back(v);

	v.pos.Set(0, lengthY, 0);
	v.color.Set(0, 1, 0);
	vertexBuffer.push_back(v);

	v.pos.Set(0, 0, -lengthZ);
	v.color.Set(0, 0, 1);
	vertexBuffer.push_back(v);

	v.pos.Set(0, 0, lengthZ);
	v.color.Set(0, 0, 1);
	vertexBuffer.push_back(v);

	indexBuffer.push_back(0);
	indexBuffer.push_back(1);
	indexBuffer.push_back(2);
	indexBuffer.push_back(3);
	indexBuffer.push_back(4);
	indexBuffer.push_back(5);

	Mesh *mesh = new Mesh(meshName);
	
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh->indexBuffer); //bind index buffer
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, indexBuffer.size() * sizeof(GLuint), &indexBuffer[0], GL_STATIC_DRAW);

	// Set the current active buffer
	glBindBuffer(GL_ARRAY_BUFFER, mesh->vertexBuffer);
	// Transfer vertices to OpenGL
	glBufferData(GL_ARRAY_BUFFER, vertexBuffer.size() * sizeof(Vertex), &vertexBuffer[0], GL_STATIC_DRAW);

	mesh->indexSize = indexBuffer.size();
	mesh->mode = Mesh::DRAW_LINES;

	return mesh;
	
}


Mesh* MeshBuilder::GenerateRing(const std::string &meshName, float innerRadius, float outerRadius) 
{
	std::vector<Vertex> vertexBuffer;
	std::vector<GLuint> indexBuffer;

	Vertex v;

	for (float theta = 0.0; theta <= (2 * 3.14159); theta += 0.01)
	{
		v.pos.Set(outerRadius * (cosf(theta)), 0, outerRadius * (sinf(theta)));
		v.color.Set(1, 1, 0);
		v.normal.Set(0, 1, 0);
		vertexBuffer.push_back(v);

		v.pos.Set(innerRadius * (cosf(theta)), 0, innerRadius * (sinf(theta)));
		v.color.Set(1, 1, 0);
		v.normal.Set(0, 1, 0);
		vertexBuffer.push_back(v);
	}

	for (size_t i = 0; i < vertexBuffer.size(); i++) 
	{
		indexBuffer.push_back(i);
	}

	Mesh *mesh = new Mesh(meshName);

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh->indexBuffer); //bind index buffer
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, indexBuffer.size() * sizeof(GLuint), &indexBuffer[0], GL_STATIC_DRAW);
	// Set the current active buffer
	glBindBuffer(GL_ARRAY_BUFFER, mesh->vertexBuffer);
	// Transfer vertices to OpenGL
	glBufferData(GL_ARRAY_BUFFER, vertexBuffer.size() * sizeof(Vertex), &vertexBuffer[0], GL_STATIC_DRAW);

	mesh->indexSize = indexBuffer.size();
	mesh->mode = Mesh::DRAW_TRIANGLE_STRIP;

	return mesh;
}

float DegreeToRadian(float value)
{
	return value * 3.142 / 180.0f;
}

float sphereX(float phi, float theta)
{
	return cos(DegreeToRadian(phi)) * cos(DegreeToRadian(theta));
}
float sphereY(float phi, float theta)
{
	return sin(DegreeToRadian(phi));
}
float sphereZ(float phi, float theta)
{
	return cos(DegreeToRadian(phi)) * sin(DegreeToRadian(theta));
}
Mesh* MeshBuilder::GenerateSphere(const std::string &meshName, Color color,unsigned numStack, unsigned numSlice, float radius)
{
	std::vector<Vertex> vertex_buffer_data;
	std::vector<GLuint> index_buffer_data;

	float degreePerStack = 180.f / numStack;
	float degreePerSlice = 360.f / numSlice;


	for (unsigned stack = 0; stack < numStack + 1; ++stack)
	{
		float phi = -90.0f + stack * degreePerStack;

		for (unsigned slice = 0; slice < numSlice + 1; ++slice)
		{
			float theta = slice *degreePerSlice;
			Vertex v;

			v.pos.Set(radius* sphereX(phi, theta), radius*sphereY(phi, theta), radius*sphereZ(phi, theta));
			v.color = color;
			v.normal.Set(sphereX(phi, theta), sphereY(phi, theta), sphereZ(phi, theta));
			vertex_buffer_data.push_back(v);
		}
	}

	for (unsigned stack = 0; stack < numStack; ++stack)
	{
		for (unsigned slice = 0; slice < numSlice; ++slice)
		{
			index_buffer_data.push_back((numSlice + 1) * stack + slice + 0);
			index_buffer_data.push_back((numSlice + 1) * (stack + 1) + slice + 0);
		}
	}

	Mesh *mesh = new Mesh(meshName);

	glBindBuffer(GL_ARRAY_BUFFER, mesh->vertexBuffer);
	glBufferData(GL_ARRAY_BUFFER, vertex_buffer_data.size() * sizeof(Vertex), &vertex_buffer_data[0], GL_STATIC_DRAW);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh->indexBuffer);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, index_buffer_data.size() * sizeof(GLuint), &index_buffer_data[0], GL_STATIC_DRAW);

	mesh->indexSize = index_buffer_data.size();
	mesh->mode = Mesh::DRAW_TRIANGLE_STRIP;

	return mesh;
}

Mesh* MeshBuilder::GenerateSunSphere(const std::string &meshName, float Radius)
{
	std::vector<Vertex> vertexBuffer;
	std::vector<GLuint> indexBuffer;

	Vertex v;

	for (float phi = 0.0; phi < (3.1415926); phi += 0.01)
	{
		for (float theta = 0.0; theta <= (2.0 * 3.1415926); theta += 0.01)
		{
			v.pos.Set((Radius * cosf(phi) * cosf(theta)), (Radius * sinf(phi)), (Radius * cosf(phi) * sinf(theta)));
			v.color.Set(1, 1, 1);
			vertexBuffer.push_back(v);

			v.pos.Set((Radius * cosf(phi + 10.0) * cosf(theta)), (Radius * sinf(phi + 10.0)), (Radius * cosf(phi + 10.0) * sinf(theta)));
			v.color.Set(1, 1, 1);
			vertexBuffer.push_back(v);
		}
	}

	for (size_t i = 0; i < vertexBuffer.size(); i++)
	{
		indexBuffer.push_back(i);
	}

	Mesh *mesh = new Mesh(meshName);

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh->indexBuffer); //bind index buffer
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, indexBuffer.size() * sizeof(GLuint), &indexBuffer[0], GL_STATIC_DRAW);
	// Set the current active buffer
	glBindBuffer(GL_ARRAY_BUFFER, mesh->vertexBuffer);
	// Transfer vertices to OpenGL
	glBufferData(GL_ARRAY_BUFFER, vertexBuffer.size() * sizeof(Vertex), &vertexBuffer[0], GL_STATIC_DRAW);

	mesh->indexSize = indexBuffer.size();
	mesh->mode = Mesh::DRAW_TRIANGLE_STRIP;

	return mesh;
}

Mesh* MeshBuilder::GenerateEarthSphere(const std::string &meshName, float Radius)
{
	std::vector<Vertex> vertexBuffer;
	std::vector<GLuint> indexBuffer;

	Vertex v;

	for (float phi = 0.0; phi < (3.1415926); phi += 0.01)
	{
		for (float theta = 0.0; theta <= (2.0 * 3.1415926); theta += 0.01)
		{
			v.pos.Set((Radius * cosf(phi) * cosf(theta)), (Radius * sinf(phi)), (Radius * cosf(phi) * sinf(theta)));
			v.color.Set(0, 0, 1);
			vertexBuffer.push_back(v);

			v.pos.Set((Radius * cosf(phi + 10.0) * cosf(theta)), (Radius * sinf(phi + 10.0)), (Radius * cosf(phi + 10.0) * sinf(theta)));
			v.color.Set(0, 0, 1);
			vertexBuffer.push_back(v);
		}
	}

	for (size_t i = 0; i < vertexBuffer.size(); i++)
	{
		indexBuffer.push_back(i);
	}

	Mesh *mesh = new Mesh(meshName);

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh->indexBuffer); //bind index buffer
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, indexBuffer.size() * sizeof(GLuint), &indexBuffer[0], GL_STATIC_DRAW);
	// Set the current active buffer
	glBindBuffer(GL_ARRAY_BUFFER, mesh->vertexBuffer);
	// Transfer vertices to OpenGL
	glBufferData(GL_ARRAY_BUFFER, vertexBuffer.size() * sizeof(Vertex), &vertexBuffer[0], GL_STATIC_DRAW);

	mesh->indexSize = indexBuffer.size();
	mesh->mode = Mesh::DRAW_TRIANGLE_STRIP;

	return mesh;
}

Mesh* MeshBuilder::GenerateMoonSphere(const std::string &meshName, Color color,unsigned numStack, unsigned numSlice, float radius)
{
	std::vector<Vertex> vertex_buffer_data;
	std::vector<GLuint> index_buffer_data;

	float degreePerStack = 180.f / numStack;
	float degreePerSlice = 360.f / numSlice;


	for (unsigned stack = 0; stack < numStack + 1; ++stack)
	{
		float phi = -90.0f + stack * degreePerStack;

		for (unsigned slice = 0; slice < numSlice + 1; ++slice)
		{
			float theta = slice *degreePerSlice;
			Vertex v;

			v.pos.Set(radius* sphereX(phi, theta), radius*sphereY(phi, theta), radius*sphereZ(phi, theta));
			v.color = color;
			v.normal.Set(sphereX(phi, theta), sphereY(phi, theta), sphereZ(phi, theta));
			vertex_buffer_data.push_back(v);
		}
	}

	for (unsigned stack = 0; stack < numStack; ++stack)
	{
		for (unsigned slice = 0; slice < numSlice; ++slice)
		{
			index_buffer_data.push_back((numSlice + 1) * stack + slice + 0);
			index_buffer_data.push_back((numSlice + 1) * (stack + 1) + slice + 0);
		}
	}

	Mesh *mesh = new Mesh(meshName);

	glBindBuffer(GL_ARRAY_BUFFER, mesh->vertexBuffer);
	glBufferData(GL_ARRAY_BUFFER, vertex_buffer_data.size() * sizeof(Vertex), &vertex_buffer_data[0], GL_STATIC_DRAW);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh->indexBuffer);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, index_buffer_data.size() * sizeof(GLuint), &index_buffer_data[0], GL_STATIC_DRAW);

	mesh->indexSize = index_buffer_data.size();
	mesh->mode = Mesh::DRAW_TRIANGLE_STRIP;

	return mesh;
}

/******************************************************************************/
/*!
\brief
Generate the vertices of a cube; Use random color for each vertex
Then generate the VBO/IBO and store them in Mesh object

\param meshName - name of mesh
\param lengthX - width of cube
\param lengthY - height of cube
\param lengthZ - depth of cube

\return Pointer to mesh storing VBO/IBO of cube
*/
/******************************************************************************/
Mesh* MeshBuilder::GenerateCube(const std::string &meshName, Color color, float lengthX, float lengthY, float lengthZ)
{
	std::vector<Vertex> vertex_buffer_data;
	Vertex v;

	v.pos.Set(-0.5 * lengthX, 0.5 * lengthY, 0.5 * lengthZ);
	v.color = color;
	vertex_buffer_data.push_back(v);
	v.pos.Set(-0.5 * lengthX, -0.5 * lengthY, 0.5 * lengthZ);
	v.color = color;
	vertex_buffer_data.push_back(v);
	v.pos.Set(0.5 * lengthX, 0.5 * lengthY, 0.5 * lengthZ);
	v.color = color;
	vertex_buffer_data.push_back(v);
	v.pos.Set(0.5 * lengthX, 0.5 * lengthY, 0.5 * lengthZ);
	v.color = color;
	vertex_buffer_data.push_back(v);
	v.pos.Set(-0.5 * lengthX, -0.5 * lengthY, 0.5 * lengthZ);
	v.color = color;
	vertex_buffer_data.push_back(v);
	v.pos.Set(0.5 * lengthX, -0.5 * lengthY, 0.5 * lengthZ);
	v.color = color;
	vertex_buffer_data.push_back(v);
	v.pos.Set(0.5 * lengthX, 0.5 * lengthY, 0.5 * lengthZ);
	v.color = color;
	vertex_buffer_data.push_back(v);
	v.pos.Set(0.5 * lengthX, -0.5 * lengthY, 0.5 * lengthZ);
	v.color = color;
	vertex_buffer_data.push_back(v);
	v.pos.Set(0.5 * lengthX, 0.5 * lengthY, -0.5 * lengthZ);
	v.color = color;
	vertex_buffer_data.push_back(v);
	v.pos.Set(0.5 * lengthX, 0.5 * lengthY, -0.5 * lengthZ);
	v.color = color;
	vertex_buffer_data.push_back(v);
	v.pos.Set(0.5 * lengthX, -0.5 * lengthY, 0.5 * lengthZ);
	v.color = color;
	vertex_buffer_data.push_back(v);
	v.pos.Set(0.5 * lengthX, -0.5 * lengthY, -0.5 * lengthZ);
	v.color = color;
	vertex_buffer_data.push_back(v);
	v.pos.Set(0.5 * lengthX, 0.5 * lengthY, -0.5 * lengthZ);
	v.color = color;
	vertex_buffer_data.push_back(v);
	v.pos.Set(-0.5 * lengthX, 0.5 * lengthY, -0.5 * lengthZ);
	v.color = color;
	vertex_buffer_data.push_back(v);
	v.pos.Set(-0.5 * lengthX, 0.5 * lengthY, 0.5 * lengthZ);
	v.color = color;
	vertex_buffer_data.push_back(v);
	v.pos.Set(0.5 * lengthX, 0.5 * lengthY, -0.5 * lengthZ);
	v.color = color;
	vertex_buffer_data.push_back(v);
	v.pos.Set(-0.5 * lengthX, 0.5 * lengthY, 0.5 * lengthZ);
	v.color = color;
	vertex_buffer_data.push_back(v);
	v.pos.Set(0.5 * lengthX, 0.5 * lengthY, 0.5 * lengthZ);
	v.color = color;
	vertex_buffer_data.push_back(v);
	v.pos.Set(-0.5 * lengthX, 0.5 * lengthY, -0.5 * lengthZ);
	v.color = color;
	vertex_buffer_data.push_back(v);
	v.pos.Set(-0.5 * lengthX, -0.5 * lengthY, -0.5 * lengthZ);
	v.color = color;
	vertex_buffer_data.push_back(v);
	v.pos.Set(-0.5 * lengthX, 0.5 * lengthY, 0.5 * lengthZ);
	v.color = color;
	vertex_buffer_data.push_back(v);
	v.pos.Set(-0.5 * lengthX, 0.5 * lengthY, 0.5 * lengthZ);
	v.color = color;
	vertex_buffer_data.push_back(v);
	v.pos.Set(-0.5 * lengthX, -0.5 * lengthY, -0.5 * lengthZ);
	v.color = color;
	vertex_buffer_data.push_back(v);
	v.pos.Set(-0.5 * lengthX, -0.5 * lengthY, 0.5 * lengthZ);
	v.color = color;
	vertex_buffer_data.push_back(v);
	v.pos.Set(-0.5 * lengthX, -0.5 * lengthY, -0.5 * lengthZ);
	v.color = color;
	vertex_buffer_data.push_back(v);
	v.pos.Set(0.5 * lengthX, -0.5 * lengthY, -0.5 * lengthZ);
	v.color = color;
	vertex_buffer_data.push_back(v);
	v.pos.Set(0.5 * lengthX, -0.5 * lengthY, 0.5 * lengthZ);
	v.color = color;
	vertex_buffer_data.push_back(v);
	v.pos.Set(-0.5 * lengthX, -0.5 * lengthY, -0.5 * lengthZ);
	v.color = color;
	vertex_buffer_data.push_back(v);
	v.pos.Set(0.5 * lengthX, -0.5 * lengthY, 0.5 * lengthZ);
	v.color = color;
	vertex_buffer_data.push_back(v);
	v.pos.Set(-0.5 * lengthX, -0.5 * lengthY, 0.5 * lengthZ);
	v.color = color;
	vertex_buffer_data.push_back(v);
	v.pos.Set(-0.5 * lengthX, 0.5 * lengthY, -0.5 * lengthZ);
	v.color = color;
	vertex_buffer_data.push_back(v);
	v.pos.Set(0.5 * lengthX, -0.5 * lengthY, -0.5 * lengthZ);
	v.color = color;
	vertex_buffer_data.push_back(v);
	v.pos.Set(-0.5 * lengthX, -0.5 * lengthY, -0.5 * lengthZ);
	v.color = color;
	vertex_buffer_data.push_back(v);
	v.pos.Set(-0.5 * lengthX, 0.5 * lengthY, -0.5 * lengthZ);
	v.color = color;
	vertex_buffer_data.push_back(v);
	v.pos.Set(0.5 * lengthX, 0.5 * lengthY, -0.5 * lengthZ);
	v.color = color;
	vertex_buffer_data.push_back(v);
	v.pos.Set(0.5 * lengthX, -0.5 * lengthY, -0.5 * lengthZ);
	v.color = color;
	vertex_buffer_data.push_back(v);


	std::vector<GLuint> index_buffer_data;

	for (int i = 0; i < vertex_buffer_data.size(); ++i)
	{
		index_buffer_data.push_back(i);
	}

	Mesh *mesh = new Mesh(meshName);

	glBindBuffer(GL_ARRAY_BUFFER, mesh->vertexBuffer);
	glBufferData(GL_ARRAY_BUFFER, vertex_buffer_data.size() * sizeof(Vertex), &vertex_buffer_data[0], GL_STATIC_DRAW);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh->indexBuffer);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, index_buffer_data.size() * sizeof(GLuint), &index_buffer_data[0], GL_STATIC_DRAW);

	mesh->indexSize = index_buffer_data.size();
	mesh->mode = Mesh::DRAW_TRIANGLES;
	return mesh;
}


/******************************************************************************/
/*!
\brief
Generate the vertices of a quad; Use random color for each vertex
Then generate the VBO/IBO and store them in Mesh object

\param meshName - name of mesh
\param lengthX - width of quad
\param lengthY - height of quad

\return Pointer to mesh storing VBO/IBO of quad
*/
/******************************************************************************/
Mesh* MeshBuilder::GenerateQuad(const std::string &meshName, Color color, float lengthX, float lengthY)
{
	std::vector<Vertex> vertex_buffer_data;
	Vertex v;

	v.pos.Set(-0.5 * lengthX, -0.5 * lengthY, 0);
	v.color = color;
	v.normal.Set(1, 0, 0);
	v.texCoord.Set(0, 0);
	vertex_buffer_data.push_back(v);

	v.pos.Set(0.5 * lengthX, -0.5 * lengthY, 0);
	v.color = color;
	v.normal.Set(1, 0, 0);
	v.texCoord.Set(1, 0);
	vertex_buffer_data.push_back(v);

	v.pos.Set(-0.5 * lengthX, 0.5 * lengthY, 0);
	v.color = color;
	v.normal.Set(1, 0, 0);
	v.texCoord.Set(0, 1);
	//v.texCoord.Set(0, 0.5);
	//v.texCoord.Set(0, 10);
	vertex_buffer_data.push_back(v);

	v.pos.Set(-0.5 * lengthX, 0.5 * lengthY, 0);
	v.color = color;
	v.normal.Set(1, 0, 0);
	v.texCoord.Set(0, 1);
	//v.texCoord.Set(0, 0.5);
	//v.texCoord.Set(0, 10);
	vertex_buffer_data.push_back(v);

	v.pos.Set(0.5 * lengthX, -0.5 * lengthY, 0);
	v.color = color;
	v.normal.Set(1, 0, 0);
	v.texCoord.Set(1, 0);
	vertex_buffer_data.push_back(v);

	v.pos.Set(0.5 * lengthX, 0.5 * lengthY, 0);
	v.color = color;
	v.normal.Set(1, 0, 0);
	v.texCoord.Set(1, 1);
	vertex_buffer_data.push_back(v);

	std::vector<GLuint> index_buffer_data;

	for (int i = 0; i < vertex_buffer_data.size(); ++i)
	{
		index_buffer_data.push_back(i);
	}

	Mesh *mesh = new Mesh(meshName);

	glBindBuffer(GL_ARRAY_BUFFER, mesh->vertexBuffer);
	glBufferData(GL_ARRAY_BUFFER, vertex_buffer_data.size() * sizeof(Vertex), &vertex_buffer_data[0], GL_STATIC_DRAW);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh->indexBuffer);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, index_buffer_data.size() * sizeof(GLuint), &index_buffer_data[0], GL_STATIC_DRAW);

	mesh->indexSize = index_buffer_data.size();
	mesh->mode = Mesh::DRAW_TRIANGLES;

	return mesh;
}

//Flat Circle
Mesh* MeshBuilder::Circle(const std::string &meshName, float Radius)
{
	std::vector<Vertex> vertex_buffer_data;
	Vertex v;

	for (float theta = 0; theta <= (2 * 3.1415926); theta += 0.01) 
	{
		v.pos.Set((Radius * cosf(theta)) , 0, (Radius * sinf(theta)));
		v.color.Set(1, 1, 1);
		vertex_buffer_data.push_back(v);

		v.pos.Set(0, 0, 0);
		v.color.Set(1, 1, 1);
		vertex_buffer_data.push_back(v);
	}

	std::vector<GLuint> index_buffer_data;

	for (int i = 0; i < vertex_buffer_data.size(); ++i)
	{
		index_buffer_data.push_back(i);
	}

	Mesh *mesh = new Mesh(meshName);

	glBindBuffer(GL_ARRAY_BUFFER, mesh->vertexBuffer);
	glBufferData(GL_ARRAY_BUFFER, vertex_buffer_data.size() * sizeof(Vertex), &vertex_buffer_data[0], GL_STATIC_DRAW);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh->indexBuffer);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, index_buffer_data.size() * sizeof(GLuint), &index_buffer_data[0], GL_STATIC_DRAW);

	mesh->indexSize = index_buffer_data.size();
	mesh->mode = Mesh::DRAW_TRIANGLE_STRIP;

	return mesh;
}

//Ring
Mesh* MeshBuilder::Ring(const std::string &meshName, float Radius,  float outerRadius, float innerRadius) 
{
	std::vector<Vertex> vertex_buffer_data;
	Vertex v;

	for (float theta = 0; theta <= (2 * 3.1415926); theta += 0.01)
	{
		v.pos.Set((outerRadius * (Radius * cosf(theta))), 0, (outerRadius * (Radius * sinf(theta))));
		v.color.Set(1, 1, 1);
		vertex_buffer_data.push_back(v);

		v.pos.Set((innerRadius * (Radius * cosf(theta))), 0, (innerRadius * (Radius * sinf(theta))));
		v.color.Set(1, 1, 1);
		vertex_buffer_data.push_back(v);
	}

	std::vector<GLuint> index_buffer_data;

	for (int i = 0; i < vertex_buffer_data.size(); ++i)
	{
		index_buffer_data.push_back(i);
	}

	Mesh *mesh = new Mesh(meshName);

	glBindBuffer(GL_ARRAY_BUFFER, mesh->vertexBuffer);
	glBufferData(GL_ARRAY_BUFFER, vertex_buffer_data.size() * sizeof(Vertex), &vertex_buffer_data[0], GL_STATIC_DRAW);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh->indexBuffer);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, index_buffer_data.size() * sizeof(GLuint), &index_buffer_data[0], GL_STATIC_DRAW);

	mesh->indexSize = index_buffer_data.size();
	mesh->mode = Mesh::DRAW_TRIANGLE_STRIP;

	return mesh;
}

//Half a Sphere
Mesh* MeshBuilder::Hemisphere(const std::string &meshName, float Radius) 
{
	std::vector<Vertex> vertex_buffer_data;
	Vertex v;

	for (float phi = 0; phi < (3.1415926 / 2.0) ; phi += 0.01)
	{
		for (float theta = 0; theta <= (2 * 3.1415926); theta += 0.01)
		{
			v.pos.Set((Radius * (Radius * cosf(phi) * cosf(theta))), (Radius * (Radius * sinf(phi))), (Radius * (Radius * cosf(phi) * sinf(theta))));
			v.color.Set(1, 1, 1);
			vertex_buffer_data.push_back(v);

			v.pos.Set((Radius * (Radius * cosf(phi + 0.01) * cosf(theta))), (Radius * (Radius * sinf(phi + 0.01))), (Radius * (Radius * cosf(phi + 0.01) * sinf(theta))));
			v.color.Set(1, 1, 1);
			vertex_buffer_data.push_back(v);
		}
	}

	for (float theta = 0; theta <= (2 * 3.1415926); theta += 0.01)
	{
		v.pos.Set(0, 0, 0);
		v.color.Set(1, 1, 1);
		vertex_buffer_data.push_back(v);

		v.pos.Set((Radius * (Radius * cosf(theta))), 0, (Radius * (Radius * sinf(theta))));
		v.color.Set(1, 1, 1);
		vertex_buffer_data.push_back(v);
	}

	std::vector<GLuint> index_buffer_data;

	for (int i = 0; i < vertex_buffer_data.size(); ++i)
	{
		index_buffer_data.push_back(i);
	}

	Mesh *mesh = new Mesh(meshName);

	glBindBuffer(GL_ARRAY_BUFFER, mesh->vertexBuffer);
	glBufferData(GL_ARRAY_BUFFER, vertex_buffer_data.size() * sizeof(Vertex), &vertex_buffer_data[0], GL_STATIC_DRAW);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh->indexBuffer);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, index_buffer_data.size() * sizeof(GLuint), &index_buffer_data[0], GL_STATIC_DRAW);

	mesh->indexSize = index_buffer_data.size();
	mesh->mode = Mesh::DRAW_TRIANGLE_STRIP;

	return mesh;
}

//Object Model
Mesh* MeshBuilder::GenerateOBJ(const std::string &meshName, const std::string &file_path) {
	//Read vertices, texcoords & normals from OBJ
	std::vector<Position> vertices;
	std::vector<TexCoord> uvs;
	std::vector<Vector3> normals;
	bool success = LoadOBJ(file_path.c_str(), vertices, uvs, normals);
	if (!success)
		return NULL;
	//Index the vertices, texcoords & normals properly
	std::vector<Vertex> vertex_buffer_data;
	std::vector<GLuint> index_buffer_data;
	IndexVBO(vertices, uvs, normals, index_buffer_data, vertex_buffer_data);

	//Create the mesh and call glBindBuffer, glBufferData
	//Use triangle list and remember to set index size

	Mesh *mesh = new Mesh(meshName);

	glBindBuffer(GL_ARRAY_BUFFER, mesh->vertexBuffer);
	glBufferData(GL_ARRAY_BUFFER, vertex_buffer_data.size() * sizeof(Vertex), &vertex_buffer_data[0], GL_STATIC_DRAW);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh->indexBuffer);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, index_buffer_data.size() * sizeof(GLuint), &index_buffer_data[0], GL_STATIC_DRAW);

	mesh->indexSize = index_buffer_data.size();
	mesh->mode = Mesh::DRAW_TRIANGLES;
	return mesh;
}

//Text
Mesh* MeshBuilder::GenerateText(const std::string &meshName, unsigned numRow, unsigned numCol)
{
	std::vector<Vertex> vertex_buffer_data;
	std::vector<GLuint> index_buffer_data;

	Vertex v;

	float width = 1.f / numCol;
	float height = 1.f / numRow;
	int offset = 0;

	for (unsigned j = 0; j < numRow; ++j)
	{
		for (unsigned i = 0; i < numCol; ++i)
		{
			float u1 = i * width;
			float v1 = 1.f - height - j * height;

			//Task: Add 4 vertices into vertex_buffer_data
			v.pos.Set(-0.5, -0.5, 0);
			v.texCoord.Set(u1, v1);
			vertex_buffer_data.push_back(v);

			v.pos.Set(0.5, -0.5, 0);
			v.texCoord.Set(u1 + width , v1);
			vertex_buffer_data.push_back(v);

			v.pos.Set(0.5, 0.5, 0);
			v.texCoord.Set(u1 + width, v1 + height);
			vertex_buffer_data.push_back(v);

			v.pos.Set(-0.5, 0.5, 0);
			v.texCoord.Set(u1, v1 + height);
			vertex_buffer_data.push_back(v);

			//Task: Add 6 indices into index_buffer_data
			index_buffer_data.push_back(offset + 0);
			index_buffer_data.push_back(offset + 1);
			index_buffer_data.push_back(offset + 2);
			index_buffer_data.push_back(offset + 0);
			index_buffer_data.push_back(offset + 2);
			index_buffer_data.push_back(offset + 3);
			offset += 4;
		}
	}

	Mesh *mesh = new Mesh(meshName);

	glBindBuffer(GL_ARRAY_BUFFER, mesh->vertexBuffer);
	glBufferData(GL_ARRAY_BUFFER, vertex_buffer_data.size() * sizeof(Vertex), &vertex_buffer_data[0], GL_STATIC_DRAW);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, mesh->indexBuffer);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, index_buffer_data.size() * sizeof(GLuint), &index_buffer_data[0], GL_STATIC_DRAW);

	mesh->indexSize = index_buffer_data.size();
	mesh->mode = Mesh::DRAW_TRIANGLES;

	return mesh;
}
