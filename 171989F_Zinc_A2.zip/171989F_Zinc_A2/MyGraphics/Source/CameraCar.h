
#include "Camera.h"

class CameraCar : public Camera
{
public:

	//Vector3 position;
	//Vector3 target;
	//Vector3 up;

	Vector3 defaultPosition;
	Vector3 defaultTarget;
	Vector3 defaultUp;

	Vector3 positionOffset;

	CameraCar();
	~CameraCar();
	void Init(const Vector3& pos, const Vector3& target, const Vector3& up);
	void Update(Vector3 carpos);
	void Reset();

private:
	float rotateAngle;

};