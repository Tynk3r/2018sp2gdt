#include "MyCar.h"
#include "Application.h"
#include "Mtx44.h"

MyCar::MyCar()
{
}


MyCar::~MyCar()
{
}

void MyCar::Init(const Vector3& pos)
{
	this->maxSpeed = 20;
	this->currentVelocity = 0;
	this->acceleration = 0;
	this->steeringSpeed = 0.5;
	this->position = defaultPosition = pos ;
	this->FrontView.Init(
							Vector3(-2, 0.8, -0.3),
							(pos + Vector3(0, 0.3, -0.3)),
							Vector3(0, 1, 0)
						);
}

void MyCar::Update()
{
	Vector3 front = this->FrontView.position;
	Vector3 view = (front - position).Normalized();
	Vector3 right = view.Cross(Vector3(0,1,0));

	if (Application::IsKeyPressed(VK_UP) || Application::IsKeyPressed('W'))
	{
		acceleration = 0.01;
		if (this->currentVelocity < maxSpeed)
		{
			if (currentVelocity < 0)
			{
				acceleration = 0.04;
			}
			this->currentVelocity = currentVelocity + acceleration;
		}
		else
		{
			this->currentVelocity = maxSpeed;
		}
		if (this->position.x < 49)
		{
			if (this->position.x <= -47)
			{
				this->currentVelocity = 0.05;
				this->position.x += currentVelocity;
			}
			else
			{
				this->position.x += currentVelocity;
			}
		}

	}
	if (Application::IsKeyPressed(VK_DOWN) || Application::IsKeyPressed('S'))
	{
		acceleration = -0.01;
		if (this->currentVelocity > -maxSpeed)
		{
			if (currentVelocity > 0)
			{
				acceleration = -0.04;
			}
			this->currentVelocity = currentVelocity + acceleration;
		}
		else
		{
			this->currentVelocity = -maxSpeed;
		}
		if (this->position.x > -47)
		{
			if (this->position.x >= 49)
			{
				this->currentVelocity = -0.05;
				this->position.x += currentVelocity;
			}
			else
			{
				this->position.x += currentVelocity;
			}
		}
	}
	if (Application::IsKeyPressed(VK_LEFT) || Application::IsKeyPressed('A'))
	{
		steering += steeringSpeed;

	}
	if (Application::IsKeyPressed(VK_RIGHT) || Application::IsKeyPressed('D'))
	{
		steering -= steeringSpeed;
	}

	if (Application::IsKeyPressed('R'))
	{
		this->FrontView.Reset();
		this->position = defaultPosition;
		this->acceleration = 0;
	}

	if ((!Application::IsKeyPressed('W')) && (!Application::IsKeyPressed('S')))
	{
		if (currentVelocity != 0)
		{
			if (currentVelocity > 0)
			{
				acceleration = -0.01;
				currentVelocity = currentVelocity + acceleration;
				this->position.x += currentVelocity;
			}
			else if (currentVelocity < 0)
			{
				acceleration = 0.01;
				currentVelocity = currentVelocity + acceleration;
				this->position.x += currentVelocity;
			}
		}
	}

	if (Application::IsKeyPressed(VK_SPACE))
	{
		if (currentVelocity != 0)
		{
			if (currentVelocity > 0)
			{
				acceleration = -0.05;
				currentVelocity = currentVelocity + acceleration;
				this->position.x += currentVelocity;
			}
			else if (currentVelocity < 0)
			{
				acceleration = 0.05;
				currentVelocity = currentVelocity + acceleration;
				this->position.x += currentVelocity;
			}
		}
	}

	this->FrontView.Update(this->position);
}
