#define MY_CAR_H
#include "Vector3.h"
#include "CameraCar.h"

class MyCar
{
private:
public:
	MyCar();
	~MyCar();

	Vector3 position;
	Vector3 defaultPosition;
	float steering;
	float steeringSpeed;

	float maxSpeed;
	float currentVelocity;
	float acceleration;

	CameraCar FrontView;
	CameraCar BackView;

	void Init(const Vector3& pos);
	void Update(); //Updates movement and calls Update() for camera
};

