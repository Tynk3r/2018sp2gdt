
#ifndef APPLICATION_H
#define APPLICATION_H

#include "timer.h"

class Application
{
public:
	Application();
	~Application();
	void Init();
	void Run();
	void Exit();
	static bool IsKeyPressed(unsigned short key);
	static int getMouseXleft(void);
	static int getMouseXright(void);
	static int getMouseYup(void);
	static int getMouseYdown(void);
	static int getMouseX(void);
	static int getMouseY(void);

private:

	//Declare a window object
	StopWatch m_timer;
};

#endif