#ifndef CAMERA_4_H
#define CAMERA_4_H

#include "Camera.h"

class Camera4 : public Camera
{
public:

	enum Camera_Mode
	{
		WALKING,
		DRIVING
	};

	//Vector3 position;
	//Vector3 target;
	//Vector3 up;

	Vector3 defaultPosition;
	Vector3 defaultTarget;
	Vector3 defaultUp;

	Camera4();
	~Camera4();
	void Init(const Vector3& pos, const Vector3& target, const Vector3& up);
	void Update(double dt);
	void Reset();
	void ChangeMode(Camera_Mode);

private:
	float rotateAngle;

	Camera_Mode currentMode;

	
};

#endif