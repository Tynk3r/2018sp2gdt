#include "SceneMain.h"
#include "GL\glew.h"

#include "shader.hpp"
#include "Mtx44.h"
#include "Application.h"
#include "Utility.h"
#include "LoadTGA.h"

using namespace std;

SceneMain::SceneMain()
{
}

SceneMain::~SceneMain()
{
}

void SceneMain::Init()
{
	glClearColor(0.0f, 0.0f, 0.4f, 0.0f);

	// Generate a default VAO for now
	glGenVertexArrays(1, &m_vertexArrayID);
	glBindVertexArray(m_vertexArrayID);
	glDisable(GL_CULL_FACE);

	// Enable blending
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	car.Init(Vector3(-45, 0, 0));

	Mtx44 projection;
	projection.SetToPerspective(45.f, 4.f / 3.f, 0.1f, 1000.f);
	projectionStack.LoadMatrix(projection);

	rotateAngle = 0.0f;
	translateX = 0.0f;
	scaleAll = 0.0f;

	rotateAmt = 60;
	translateAmt = 10;
	scaleAmt = 2;

	cameraMode = 0;
	camera.Init(Vector3(0,20,0),Vector3(1,1,1),Vector3(0,1,0));

	//Load vertex and fragment shaders
	m_programID = LoadShaders("Shader//Texture.vertexshader", "Shader//Text.fragmentshader");

	// Get a handle for our "MVP" uniform
	m_parameters[U_MVP] = glGetUniformLocation(m_programID, "MVP");

	m_parameters[U_MODELVIEW] = glGetUniformLocation(m_programID, "MV");
	m_parameters[U_MODELVIEW_INVERSE_TRANSPOSE] = glGetUniformLocation(m_programID, "MV_inverse_transpose");
	m_parameters[U_MATERIAL_AMBIENT] = glGetUniformLocation(m_programID, "material.kAmbient");
	m_parameters[U_MATERIAL_DIFFUSE] = glGetUniformLocation(m_programID, "material.kDiffuse");
	m_parameters[U_MATERIAL_SPECULAR] = glGetUniformLocation(m_programID, "material.kSpecular");
	m_parameters[U_MATERIAL_SHININESS] = glGetUniformLocation(m_programID, "material.kShininess");
	m_parameters[U_LIGHT0_POSITION] = glGetUniformLocation(m_programID, "lights[0].position_cameraspace");
	m_parameters[U_LIGHT0_COLOR] = glGetUniformLocation(m_programID, "lights[0].color");
	m_parameters[U_LIGHT0_POWER] = glGetUniformLocation(m_programID, "lights[0].power");
	m_parameters[U_LIGHT0_KC] = glGetUniformLocation(m_programID, "lights[0].kC");
	m_parameters[U_LIGHT0_KL] = glGetUniformLocation(m_programID, "lights[0].kL");
	m_parameters[U_LIGHT0_KQ] = glGetUniformLocation(m_programID, "lights[0].kQ");
	m_parameters[U_LIGHTENABLED] = glGetUniformLocation(m_programID, "lightEnabled");
	m_parameters[U_NUMLIGHTS] = glGetUniformLocation(m_programID, "numLights");
	// Get a handle for our "colorTexture" uniform
	m_parameters[U_COLOR_TEXTURE_ENABLED] = glGetUniformLocation(m_programID, "colorTextureEnabled");
	m_parameters[U_COLOR_TEXTURE] = glGetUniformLocation(m_programID, "colorTexture");
	// Get a handle for our "textColor" uniform
	m_parameters[U_TEXT_ENABLED] = glGetUniformLocation(m_programID, "textEnabled");
	m_parameters[U_TEXT_COLOR] = glGetUniformLocation(m_programID, "textColor");

	// Use our shader
	glUseProgram(m_programID);
	// Enable depth test
	glEnable(GL_DEPTH_TEST);

	light[0].type = Light::LIGHT_DIRECTIONAL;
	light[0].position.Set(20, 35, 25);
	light[0].color.Set(1, 1, 1);
	light[0].power = 5;
	light[0].kC = 1.f;
	light[0].kL = 0.01f;
	light[0].kQ = 0.001f;

	carLight[0].type = Light::LIGHT_POINT;
	carLight[0].position.Set((car.position.x + 2), car.position.y, car.position.z);
	carLight[0].color.Set(1, 0.01, 0.01);
	carLight[0].power = 1;
	carLight[0].kC = 1.f;
	carLight[0].kL = 0.01f;
	carLight[0].kQ = 0.001f;

	// Make sure you pass uniform parameters after glUseProgram()
	glUniform3fv(m_parameters[U_LIGHT0_COLOR], 1, &light[0].color.r);
	glUniform1f(m_parameters[U_LIGHT0_POWER], light[0].power);
	glUniform1f(m_parameters[U_LIGHT0_KC], light[0].kC);
	glUniform1f(m_parameters[U_LIGHT0_KL], light[0].kL);
	glUniform1f(m_parameters[U_LIGHT0_KQ], light[0].kQ);

	glUniform1i(m_parameters[U_NUMLIGHTS], 1);

	for (int i = 0; i < NUM_GEOMETRY; ++i) 
	{
		meshList[i] = NULL;
	}

	//HELPERS
	meshList[GEO_AXES] = MeshBuilder::GenerateAxes("reference", 1000, 1000, 1000);
	meshList[GEO_LIGHTBALL] = MeshBuilder::GenerateSphere("Lightball", Color(1, 1, 1), 9, 36, 1);
	meshList[GEO_CAMERABALL] = MeshBuilder::GenerateSphere("CameraBall", Color(0, 0, 0), 9, 36, 1);

	//SKYBOX
	meshList[GEO_QUAD] = MeshBuilder::GenerateQuad("texture", Color(1, 1, 1), 1.f, 1.f);
	meshList[GEO_QUAD]->textureID = LoadTGA("Image//color2.tga");

	meshList[GEO_FRONT] = MeshBuilder::GenerateQuad("front", Color(1, 1, 1), 1.f, 1.f);
	meshList[GEO_FRONT]->textureID = LoadTGA("Image//front.tga");

	meshList[GEO_BACK] = MeshBuilder::GenerateQuad("back", Color(1, 1, 1), 1.f, 1.f);
	meshList[GEO_BACK]->textureID = LoadTGA("Image//back.tga");

	meshList[GEO_LEFT] = MeshBuilder::GenerateQuad("left", Color(1, 1, 1), 1.f, 1.f);
	meshList[GEO_LEFT]->textureID = LoadTGA("Image//left.tga");

	meshList[GEO_RIGHT] = MeshBuilder::GenerateQuad("right", Color(1, 1, 1), 1.f, 1.f);
	meshList[GEO_RIGHT]->textureID = LoadTGA("Image//right.tga");

	meshList[GEO_TOP] = MeshBuilder::GenerateQuad("top", Color(1, 1, 1), 1.f, 1.f);
	meshList[GEO_TOP]->textureID = LoadTGA("Image//top.tga");

	meshList[GEO_BOTTOM] = MeshBuilder::GenerateQuad("bottom", Color(1, 1, 1), 1.f, 1.f);
	meshList[GEO_BOTTOM]->textureID = LoadTGA("Image//bottom.tga");
	//End of SKYBOX

	//IMAGE
	meshList[GEO_ROAD1] = MeshBuilder::GenerateQuad("road", Color(1, 1, 1), 1.f, 1.f);
	meshList[GEO_ROAD1]->textureID = LoadTGA("Image//road.tga");

	meshList[GEO_ROAD2] = MeshBuilder::GenerateQuad("road2", Color(1, 1, 1), 1.f, 1.f);
	meshList[GEO_ROAD2]->textureID = LoadTGA("Image//concrete.tga");

	//MODELS
	meshList[GEO_CAR] = MeshBuilder::GenerateOBJ("Car", "OBJ//car.obj");
	meshList[GEO_CAR]->textureID = LoadTGA("Image//dart.tga");

	meshList[GEO_STADIUM] = MeshBuilder::GenerateOBJ("Stadium", "OBJ//stadium_beveled.obj");
	meshList[GEO_STADIUM]->textureID = LoadTGA("Image//dart.tga");

	meshList[GEO_TCONE] = MeshBuilder::GenerateOBJ("Traffic_Cone", "OBJ//tcone.obj");
	meshList[GEO_TCONE]->textureID = LoadTGA("Image//tcone.tga");

	meshList[GEO_ROADBLOCK] = MeshBuilder::GenerateOBJ("Roadblock", "OBJ//roadblock.obj");
	meshList[GEO_ROADBLOCK]->textureID = LoadTGA("Image//concrete.tga");

	//TEXT
	meshList[GEO_TEXT] = MeshBuilder::GenerateText("text", 16, 16);
	meshList[GEO_TEXT]->textureID = LoadTGA("Image//calibri.tga");

	std::cout << "loaded texture!";

	Material mat = Material();

	mat.kAmbient.Set(0.f, 0.f, 0.f);
	mat.kDiffuse.Set(0.f, 0.f, 0.f);
	mat.kSpecular.Set(0.f, 0.f, 0.f);
	mat.kShininess = 1.f;
}

void SceneMain::Update(double dt)
{
	static const float LSPEED = 10.0f;

	if (Application::IsKeyPressed('I'))
		light[0].position.z -= (float)(LSPEED * dt);
	if (Application::IsKeyPressed('K'))
		light[0].position.z += (float)(LSPEED * dt);
	if (Application::IsKeyPressed('J'))
		light[0].position.x -= (float)(LSPEED * dt);
	if (Application::IsKeyPressed('L'))
		light[0].position.x += (float)(LSPEED * dt);
	if (Application::IsKeyPressed('O'))
		light[0].position.y -= (float)(LSPEED * dt);
	if (Application::IsKeyPressed('P'))
		light[0].position.y += (float)(LSPEED * dt);

	if (Application::IsKeyPressed('1'))
	{
		glEnable(GL_CULL_FACE);
		//light[0];
	}
	if (Application::IsKeyPressed('2'))
	{
		glDisable(GL_CULL_FACE);
	}
	if (Application::IsKeyPressed('3'))
	{
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	}

	if (Application::IsKeyPressed('4'))
	{
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	}

	if (Application::IsKeyPressed('5'))
	{
		cameraMode = 1;
	}
	if (Application::IsKeyPressed('6'))
	{
		cameraMode = 2;
	}
	if (Application::IsKeyPressed('7'))
	{
		cameraMode = 3;
	}
	if (Application::IsKeyPressed('8'))
	{
		cameraMode = 4;
	}

	float upperRotateBounds = 360;
	float lowerRotateBounds = 0;

	float translateMax = 10;
	float screenMin = -10;

	float maxScale = 10;

	rotateAngle += (float)(rotateAmt * dt);
	translateX += (float)(translateAmt * dt);
	scaleAll += (float)(scaleAmt * dt);

	//Without these bounds, translate will move out of screen and scale will be too large
	if (rotateAngle > upperRotateBounds || rotateAngle < lowerRotateBounds)
		rotateAmt = -rotateAmt; // -60 or -(-60)

	if (translateX > translateMax)
		translateX = screenMin; // start from left side of screen

	if (scaleAll > maxScale)
		scaleAll = 1; // reset Scale

	car.Update();
	camera.Update(dt);
}

void SceneMain::RenderMesh(Mesh *mesh, bool enableLight)
{
	Mtx44 MVP, modelView, modelView_inverse_transpose;

	MVP = projectionStack.Top() * viewStack.Top() * modelStack.Top();
	glUniformMatrix4fv(m_parameters[U_MVP], 1, GL_FALSE, &MVP.a[0]);
	modelView = viewStack.Top() * modelStack.Top();
	glUniformMatrix4fv(m_parameters[U_MODELVIEW], 1, GL_FALSE, &modelView.a[0]);
	if (enableLight)
	{
		glUniform1i(m_parameters[U_LIGHTENABLED], 1);
		modelView_inverse_transpose = modelView.GetInverse().GetTranspose();
		glUniformMatrix4fv(m_parameters[U_MODELVIEW_INVERSE_TRANSPOSE], 1, GL_FALSE, &modelView_inverse_transpose.a[0]);

		//load material
		glUniform3fv(m_parameters[U_MATERIAL_AMBIENT], 1, &mesh->material.kAmbient.r);
		glUniform3fv(m_parameters[U_MATERIAL_DIFFUSE], 1, &mesh->material.kDiffuse.r);
		glUniform3fv(m_parameters[U_MATERIAL_SPECULAR], 1, &mesh->material.kSpecular.r);
		glUniform1f(m_parameters[U_MATERIAL_SHININESS], mesh->material.kShininess);

	}
	else
	{
		glUniform1i(m_parameters[U_LIGHTENABLED], 0);
	}
	//======================================================	
	if (mesh->textureID > 0)
	{
		glUniform1i(m_parameters[U_COLOR_TEXTURE_ENABLED], 1);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, mesh->textureID);
		glUniform1i(m_parameters[U_COLOR_TEXTURE], 0);
	}
	else
	{
		glUniform1i(m_parameters[U_COLOR_TEXTURE_ENABLED], 0);
	}
	mesh->Render();
	if (mesh->textureID > 0)
	{
		glBindTexture(GL_TEXTURE_2D, 0);
	}
}


void SceneMain::Render()
{
	//Clear color & depth buffer every frame
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	viewStack.LoadIdentity();
	if (cameraMode == 1) {
		viewStack.LookAt(car.FrontView.position.x, car.FrontView.position.y, car.FrontView.position.z, car.FrontView.target.x, car.FrontView.target.y, car.FrontView.target.z, car.FrontView.up.x, car.FrontView.up.y, car.FrontView.up.z);
	}
	else if (cameraMode == 2){
		viewStack.LookAt(-50, 5, 5, car.position.x, car.position.y, car.position.z, 0, 1, 0);
	}
	else if (cameraMode == 3) {
		viewStack.LookAt(50, 5, 5, car.position.x, car.position.y, car.position.z, 0, 1, 0);
	}
	else {
		viewStack.LookAt(1, 1, 1, car.position.x, car.position.y, car.position.z, 0, 1, 0);
	}

	//Models
	modelStack.LoadIdentity();

	Position lightPosition_cameraspace = viewStack.Top() * light[0].position;
	glUniform3fv(m_parameters[U_LIGHT0_POSITION], 1, &lightPosition_cameraspace.x);

	//Rendering the x,y,z axes
	//RenderMesh(meshList[GEO_AXES], false);
	
	//render skybox
	modelStack.PushMatrix();
	RenderSkybox();
	modelStack.PopMatrix();

	//render models

	//Floor
	modelStack.PushMatrix();
	//scale, translate, rotate
	modelStack.Scale(120, 1, 8);
	modelStack.Translate(0, -1, 0);
	modelStack.Rotate(-90, 1, 0, 0);
	RenderMesh(meshList[GEO_ROAD1], true);
	modelStack.PopMatrix();

	//Floor2
	modelStack.PushMatrix();
	//scale, translate, rotate
	modelStack.Scale(120, 1, 100);
	modelStack.Translate(0, -1.01, 0);
	modelStack.Rotate(-90, 1, 0, 0);
	RenderMesh(meshList[GEO_ROAD2], true);
	modelStack.PopMatrix();


	//Stadium
	modelStack.PushMatrix();
	//scale, translate, rotate
	modelStack.Scale(1.01, 1, 1.01);
	modelStack.Translate(30, 0, 0);
	RenderMesh(meshList[GEO_STADIUM], true);
	modelStack.PopMatrix();


	//Car
	modelStack.PushMatrix();
	//scale, translate, rotate
	modelStack.Scale(1, 1, 1);
	modelStack.Translate(car.position.x, 0, car.position.z);
	modelStack.Rotate(car.steering, 0, 1, 0);
	RenderMesh(meshList[GEO_CAR], true);
	modelStack.PopMatrix();

	//Traffic Cones (Right Side)
	for (int i = 1; i < 32; i++)
	{
		modelStack.PushMatrix();
		//scale, translate, rotate
		modelStack.Scale(1, 1, 1);
		modelStack.Translate(-65+(i*4), -1, 3);
		RenderMesh(meshList[GEO_TCONE], true);
		modelStack.PopMatrix();
	}

	//Traffic Cones (Left Side)
	for (int i = 1; i < 32; i++)
	{
		modelStack.PushMatrix();
		//scale, translate, rotate
		modelStack.Scale(1, 1, 1);
		modelStack.Translate(-65 + (i * 4), -1, -5);
		RenderMesh(meshList[GEO_TCONE], true);
		modelStack.PopMatrix();
	}

	//Roadblocks(Right Side)
	for (int i = 1; i < 91; i++)
	{
		modelStack.PushMatrix();
		//scale, translate, rotate
		modelStack.Scale(1, 1, 1);
		modelStack.Translate(-45 + (i * 1), -1, 7);
		modelStack.Rotate(90, 0, 1, 0);
		RenderMesh(meshList[GEO_ROADBLOCK], true);
		modelStack.PopMatrix();
	}

	//Roadblocks (Left Side)
	for (int i = 1; i < 91; i++)
	{
		modelStack.PushMatrix();
		//scale, translate, rotate
		modelStack.Scale(1, 1, 1);
		modelStack.Translate(-45 + (i * 1), -1, -9);
		modelStack.Rotate(90, 0, 1, 0);
		RenderMesh(meshList[GEO_ROADBLOCK], true);
		modelStack.PopMatrix();
	}

	//render text
	//modelStack.PushMatrix();
	////scale, translate, rotate
	//RenderText(meshList[GEO_TEXT], "Hello World", Color(0, 1, 0));
	//modelStack.PopMatrix();

	if (cameraMode == 1) {
		RenderTextOnScreen(meshList[GEO_TEXT], "Camera Mode : Car", Color(0, 1, 0), 2, 1, 1);
	}
	else if (cameraMode == 2) {
		RenderTextOnScreen(meshList[GEO_TEXT], "Camera Mode : Stadium Back", Color(0, 1, 0), 2, 1, 1);
	}
	else if (cameraMode == 3) {
		RenderTextOnScreen(meshList[GEO_TEXT], "Camera Mode : Stadium Front", Color(0, 1, 0), 2, 1, 1);
	}
	else {
		RenderTextOnScreen(meshList[GEO_TEXT], "Camera Mode : Stadium Middle", Color(0, 1, 0), 2, 1, 1);
	}
}

void SceneMain::RenderSkybox()
{
	modelStack.PushMatrix();
		modelStack.Translate(0, 0, 498);
		modelStack.Scale(1000, 1000, 0);
		RenderMesh(meshList[GEO_FRONT],  false);
	modelStack.PopMatrix();

	modelStack.PushMatrix();
		modelStack.Translate(0, 0, -498);
		modelStack.Rotate(180, 0, 1, 0);
		modelStack.Scale(1000, 1000, 0);
		RenderMesh(meshList[GEO_BACK], false);
	modelStack.PopMatrix();

	modelStack.PushMatrix();
		modelStack.Translate(-498, 0, 0);
		modelStack.Rotate(90, 0, 1, 0);
		modelStack.Rotate(180, 0, 1, 0);
		modelStack.Scale(1000, 1000, 0);
		RenderMesh(meshList[GEO_LEFT], false);
	modelStack.PopMatrix();

	modelStack.PushMatrix();
		modelStack.Translate(498, 0, 0);
		modelStack.Rotate(90, 0, 1, 0);
		modelStack.Scale(1000, 1000, 0);
		RenderMesh(meshList[GEO_RIGHT], false);
	modelStack.PopMatrix();

	modelStack.PushMatrix();
		modelStack.Translate(0, 498, 0);
		modelStack.Rotate(90, 0, 1, 0);
		modelStack.Rotate(-90, 1, 0, 0);
		modelStack.Scale(1000, 1000, 0);
		RenderMesh(meshList[GEO_TOP], false);
	modelStack.PopMatrix();

	modelStack.PushMatrix();
		modelStack.Translate(0, -498, 0);
		modelStack.Rotate(90, 1, 0, 0);
		modelStack.Scale(1000, 1000, 0);
		RenderMesh(meshList[GEO_BOTTOM], false);
	modelStack.PopMatrix();
}

void SceneMain::RenderText(Mesh* mesh, std::string text, Color color)
{
	if (!mesh || mesh->textureID <= 0) //Proper error check
		return;

	glDisable(GL_DEPTH_TEST);
	glUniform1i(m_parameters[U_TEXT_ENABLED], 1);
	glUniform3fv(m_parameters[U_TEXT_COLOR], 1, &color.r);
	glUniform1i(m_parameters[U_LIGHTENABLED], 0);
	glUniform1i(m_parameters[U_COLOR_TEXTURE_ENABLED], 1);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, mesh->textureID);
	glUniform1i(m_parameters[U_COLOR_TEXTURE], 0);
	for (unsigned i = 0; i < text.length(); ++i)
	{
		Mtx44 characterSpacing;
		characterSpacing.SetToTranslation(i * 1.0f, 0, 0); //1.0f is the spacing of each character, you may change this value
		Mtx44 MVP = projectionStack.Top() * viewStack.Top() * modelStack.Top() * characterSpacing;
		glUniformMatrix4fv(m_parameters[U_MVP], 1, GL_FALSE, &MVP.a[0]);

		mesh->Render((unsigned)text[i] * 6, 6);
	}
	glBindTexture(GL_TEXTURE_2D, 0);
	glUniform1i(m_parameters[U_TEXT_ENABLED], 0);
	glEnable(GL_DEPTH_TEST);

}

void SceneMain::RenderTextOnScreen(Mesh* mesh, std::string text, Color color, float size, float x, float y)
{
	if (!mesh || mesh->textureID <= 0) //Proper error check
		return;

	glDisable(GL_DEPTH_TEST);
	Mtx44 ortho;
	ortho.SetToOrtho(0, 80, 0, 60, -10, 10); //size of screen UI
	projectionStack.PushMatrix();
	projectionStack.LoadMatrix(ortho);
	viewStack.PushMatrix();
	viewStack.LoadIdentity(); //No need camera for ortho mode
	modelStack.PushMatrix();
	modelStack.LoadIdentity(); //Reset modelStack
	modelStack.Scale(size, size, size);
	modelStack.Translate(x, y, 0);
	glUniform1i(m_parameters[U_TEXT_ENABLED], 1);
	glUniform3fv(m_parameters[U_TEXT_COLOR], 1, &color.r);
	glUniform1i(m_parameters[U_LIGHTENABLED], 0);
	glUniform1i(m_parameters[U_COLOR_TEXTURE_ENABLED], 1);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, mesh->textureID);
	glUniform1i(m_parameters[U_COLOR_TEXTURE], 0);
	for (unsigned i = 0; i < text.length(); ++i)
	{
		Mtx44 characterSpacing;
		characterSpacing.SetToTranslation(i * 0.8f, 0, 0); //1.0f is the spacing of each character, you may change this value
		Mtx44 MVP = projectionStack.Top() * viewStack.Top() * modelStack.Top() * characterSpacing;
		glUniformMatrix4fv(m_parameters[U_MVP], 1, GL_FALSE, &MVP.a[0]);

		mesh->Render((unsigned)text[i] * 6, 6);
	}
	glBindTexture(GL_TEXTURE_2D, 0);
	glUniform1i(m_parameters[U_TEXT_ENABLED], 0);
	projectionStack.PopMatrix();
	viewStack.PopMatrix();
	modelStack.PopMatrix();

	glEnable(GL_DEPTH_TEST);
}


void SceneMain::Exit()
{
	// Cleanup VBO here
	for (int i = 0; i < NUM_GEOMETRY; ++i) 
	{
		if (meshList[i] != NULL) 
		{
			delete meshList[i];
		}
		meshList[i] = NULL;
	}

	glDeleteVertexArrays(1, &m_vertexArrayID);
	glDeleteProgram(m_programID);

}

//void SceneMain::BounceCheck()
//{
//	cout << camera.position << endl;
//
//	if(camera.position.x <8.0f && camera.position <=)
//}
//
//bool isPointInBox(Vector3 position, Vector3 box)
//{
//	return (position.x >= box.minX && position.x <= box.maxX) &&
//			(position.x >= box.minX && position.x <= box.maxX) &&
//			(position.x >= box.minX && position.x <= box.maxX)
//}

//Reminder

//Ask Mr Weng about multiple lights and camera following object.