#include "CameraCar.h"



CameraCar::CameraCar()
{
}


CameraCar::~CameraCar()
{
}

void CameraCar::Init(const Vector3& posOffset, const Vector3& target, const Vector3& up)
{
	this->positionOffset = posOffset;
	this->position = defaultPosition = target + posOffset;
	this->target = defaultTarget = target;
	Vector3 view = (target - position).Normalized();
	Vector3 right = view.Cross(up);
	right.y = 0;
	right.Normalize();
	this->up = defaultUp = right.Cross(view).Normalized();
}
void CameraCar::Update(Vector3 carpos)
{
	this->position = carpos + positionOffset;
	this->target = carpos;
}
void CameraCar::Reset()
{
	this->position = defaultPosition;
	this->target = defaultTarget;
	this->up = defaultUp;
}