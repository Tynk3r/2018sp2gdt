#ifndef MESH_BUILDER_H
#define MESH_BUILDER_H

#include "Mesh.h"
#include "Vertex.h"

/******************************************************************************/
/*!
		Class MeshBuilder:
\brief	Provides methods to generate mesh of different shapes
*/
/******************************************************************************/
class MeshBuilder
{
public:
	static Mesh* GenerateAxes(const std::string &meshName, float lengthX, float lengthY, float lengthZ);
	static Mesh* GenerateQuad(const std::string &meshName, Color color, float lengthX, float lengthY);
	static Mesh* GenerateCube(const std::string &meshName, Color color, float lengthX, float lengthY, float lengthZ);
	static Mesh* GenerateRing(const std::string &meshName, float innerRadius, float outerRadius);
	static Mesh* GenerateSphere(const std::string &meshName, Color color, unsigned numStack, unsigned numSlice, float radius);
	static Mesh* GenerateSunSphere(const std::string &meshName, float Radius);
	static Mesh* GenerateEarthSphere(const std::string &meshName, float Radius);
	static Mesh* GenerateMoonSphere(const std::string &meshName, Color color,unsigned numStack, unsigned numSlice, float radius);
	static Mesh* Circle(const std::string &meshName, float Radius);
	static Mesh* Ring(const std::string &meshName, float Radius, float outerRadius, float innerRadius);
	static Mesh* Hemisphere(const std::string &meshName, float Radius);
	static Mesh* GenerateOBJ(const std::string &meshName, const std::string &file_path);
	static Mesh* GenerateText(const std::string &meshName, unsigned numRow, unsigned numCol);

};

#endif