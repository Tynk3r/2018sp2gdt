#include "Camera3.h"
#include "Application.h"
#include "Mtx44.h"

Camera3::Camera3()
{
}

Camera3::~Camera3()
{
}

void Camera3::Init(const Vector3& pos, const Vector3& target, const Vector3& up)
{
	this->position = defaultPosition = pos;
	this->target = defaultTarget = target;
	Vector3 view = (target - position).Normalized();
	Vector3 right = view.Cross(up);
	right.y = 0;
	right.Normalize();
	this->up = defaultUp = right.Cross(view).Normalized();

	Xyaw = 3.14;
	Ypitch = 0;
}

void Camera3::Update(double dt)
{
	Vector3 view = target - position;
	Vector3 right = view.Cross(up);

	static const float CAMERA_SPEED = 3.f;
	static const float MOVEMENT_SPEED = 3.f;

	Application::GetMousePosition(xmousepos, ymousepos);

	Xyaw += (dt * 2 * float(800 / 2 - xmousepos));
	Ypitch += (dt * 2 * float(600 / 2 - ymousepos));

	yaw = Xyaw;
	pitch = Ypitch;

	view = (target - position).Normalized();
	right = view.Cross(up);
	right.y = 0;
	right.Normalize();
	up = right.Cross(view).Normalized();
	Mtx44 rotation;
	Mtx44 rotation2;
	rotation.SetToRotation(pitch, right.x, right.y, right.z);
	rotation2.SetToRotation(yaw, up.x, up.y, up.z);

	view = rotation * rotation2 * view;
	target = position + view;

	Application::SetMousePosition();
	Xyaw = 0;
	Ypitch = 0;

	if (Application::IsKeyPressed('A'))
	{
		position = position - right * MOVEMENT_SPEED;
		position.y = -20;
		target = position + view;
	}

	if (Application::IsKeyPressed('D'))
	{
		position = position + right * MOVEMENT_SPEED;
		position.y = -20;
		target = position + view;
	}

	if (Application::IsKeyPressed('W'))
	{
		position = position + view * MOVEMENT_SPEED;
		position.y = -20;
		target = position + view;
	}

	if (Application::IsKeyPressed('S'))
	{
		position = position - view * MOVEMENT_SPEED;
		position.y = -20;
		target = position + view;
	}
	if (Application::IsKeyPressed(VK_LEFT))
	{
		float yaw = (float)(CAMERA_SPEED * dt);
		Vector3 view = (target - position).Normalized();
		Vector3 right = view.Cross(up);
		right.y = 0;
		right.Normalize();
		up = right.Cross(view).Normalized();
		Mtx44 rotation;
		rotation.SetToRotation(yaw, up.x, up.y, up.z);

		view = rotation * view;
		target = position + view;
	}
	if (Application::IsKeyPressed(VK_RIGHT))
	{
		float yaw = (float)(-CAMERA_SPEED * dt);
		Vector3 view = (target - position).Normalized();
		Vector3 right = view.Cross(up);
		right.y = 0;
		right.Normalize();
		up = right.Cross(view).Normalized();
		Mtx44 rotation;
		rotation.SetToRotation(yaw, up.x, up.y, up.z);

		view = rotation * view;
		target = position + view;
	}
	if (Application::IsKeyPressed(VK_UP))
	{
		float pitch = (float)(CAMERA_SPEED * dt);
		Vector3 view = (target - position).Normalized();
		Vector3 right = view.Cross(up);
		right.y = 0;
		right.Normalize();
		up = right.Cross(view).Normalized();
		Mtx44 rotation;
		rotation.SetToRotation(pitch, right.x, right.y, right.z);

		view = rotation * view;
		target = position + view;
	}
	if (Application::IsKeyPressed(VK_DOWN))
	{
		float pitch = (float)(-CAMERA_SPEED * dt);
		Vector3 view = (target - position).Normalized();
		Vector3 right = view.Cross(up);
		right.y = 0;
		right.Normalize();
		up = right.Cross(view).Normalized();
		Mtx44 rotation;
		rotation.SetToRotation(pitch, right.x, right.y, right.z);

		view = rotation * view;
		target = position + view;
	}
	if (Application::IsKeyPressed('N'))
	{
		Vector3 direction = target - position;
		if (direction.Length() > 5)
		{
			Vector3 view = (target - position).Normalized();
			position += view * (float)(10.f * dt);
		}
	}
	if (Application::IsKeyPressed('M'))
	{
		Vector3 view = (target - position).Normalized();
		position -= view * (float)(10.f * dt);
	}
	if (Application::IsKeyPressed('R'))
	{
		Reset();
	}
}

void Camera3::Reset()
{
	position = defaultPosition;
	target = defaultTarget;
	up = defaultUp;
}