#ifndef BOX_H
#define BOX_H
#include "Vector3.h"

struct Length
{
	Vector3 position;

	float minX;
	float minY;
	float minZ;
	float maxX;
	float maxY;
	float maxZ;

	Length(Vector3 _position, float _Length, float _Height, float _Width)
	{
		position = _position;
		minX = position.x - _Length;
		maxX = position.x + _Length;
		minY = position.y - _Height;
		maxY = position.y + _Height;
		minZ = position.z - _Width;
		maxZ = position.z + _Width;
	}
};
#endif