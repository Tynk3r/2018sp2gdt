#include "Camera.h"
#include "Application.h"
#include "MyMath.h"
/******************************************************************************/
/*!
\brief
Default constructor
*/
/******************************************************************************/
Camera::Camera()
{
}

/******************************************************************************/
/*!
\brief
Destructor
*/
/******************************************************************************/
Camera::~Camera()
{
}

/******************************************************************************/
/*!
\brief
Initialize camera

\param pos - position of camera
\param target - where the camera is looking at
\param up - up vector of camera
*/
/******************************************************************************/
void Camera::Init(const Vector3& pos, const Vector3& target, const Vector3& up)
{
	this->position = pos;
	this->target = target;
	this->up = up;

	radius = pos.z;

}

/******************************************************************************/
/*!
\brief
Reset the camera settings
*/
/******************************************************************************/
void Camera::Reset()
{
}

/******************************************************************************/
/*!
\brief
To be called every frame. Camera will get user inputs and update its position and orientation

\param dt - frame time
*/
/******************************************************************************/
float CamerasphereX(float phi, float theta)
{
	return cos(Math::DegreeToRadian(phi)) * cos(Math::DegreeToRadian(theta));
}
float CamerasphereY(float phi, float theta)
{
	return sin(Math::DegreeToRadian(phi));
}
float CamerasphereZ(float phi, float theta)
{
	return cos(Math::DegreeToRadian(phi)) * sin(Math::DegreeToRadian(theta));
}
void Camera::Update(double dt)
{
	static const float CAMERA_SPEED = 10;

	if (Application::IsKeyPressed('D'))
	{
		theta++;
	}
	if (Application::IsKeyPressed('A'))
	{
		theta--;
	}
	if (Application::IsKeyPressed('W'))
	{
		phi++;
	}
	if (Application::IsKeyPressed('S'))
	{
		phi--;
	}
	if (Application::IsKeyPressed('N'))
	{
		if (radius < 5)
		{
			radius = 5;
		}
			radius--;

	}
	if (Application::IsKeyPressed('M'))
	{
		radius++;
	}

	/*if (camerazoom)
	{
		radius += 0.2;
	}
	else
	{
		radius -= 0.2;
	}

	if (radius >= 20)
	{
		camerazoom = false;
	}

	if (radius <= 10)
	{
		camerazoom = true;
	}*/

	position.Set(radius* CamerasphereX(phi, theta), radius*CamerasphereY(phi, theta), radius*CamerasphereZ(phi, theta));
}