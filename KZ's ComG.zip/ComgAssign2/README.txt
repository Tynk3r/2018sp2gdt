Controls
_________
Looking - Mouse
W - Forward
S - Backwards
A - Left
D - Right

E- Interaction