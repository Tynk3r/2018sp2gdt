#include "SceneText.h"
#include "GL\glew.h"
#include "Box.h"
#include <string>
#include <sstream>
#include <cstring>


#include "shader.hpp"
#include "Mtx44.h"
#include "Application.h"
#include "Utility.h"
#include "LoadTGA.h"

SceneText::SceneText()
{
	int currentFPS = 0;
}

SceneText::~SceneText()
{
}

void SceneText::Init()
{
	glClearColor(0.0f, 0.0f, 0.4f, 0.0f);

	// Generate a default VAO for now
	glGenVertexArrays(1, &m_vertexArrayID);
	glBindVertexArray(m_vertexArrayID);
	glEnable(GL_CULL_FACE);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	camera.Init(Vector3(10, -20, 10), Vector3(0, 0, 0), Vector3(0, 1, 0));

	Mtx44 projection;
	projection.SetToPerspective(45.f, 4.f / 3.f, 0.1f, 1000.f);
	projectionStack.LoadMatrix(projection);

	m_programID = LoadShaders("Shader//Texture.vertexshader", "Shader//Text.fragmentshader");

	m_parameters[U_COLOR_TEXTURE_ENABLED] = glGetUniformLocation(m_programID, "colorTextureEnabled");
	m_parameters[U_COLOR_TEXTURE] = glGetUniformLocation(m_programID, "colorTexture");


	m_parameters[U_MVP] = glGetUniformLocation(m_programID, "MVP");
	m_parameters[U_MODELVIEW] = glGetUniformLocation(m_programID, "MV");
	m_parameters[U_MODELVIEW_INVERSE_TRANSPOSE] = glGetUniformLocation(m_programID, "MV_inverse_transpose");
	m_parameters[U_MATERIAL_AMBIENT] = glGetUniformLocation(m_programID, "material.kAmbient");
	m_parameters[U_MATERIAL_DIFFUSE] = glGetUniformLocation(m_programID, "material.kDiffuse");
	m_parameters[U_MATERIAL_SPECULAR] = glGetUniformLocation(m_programID, "material.kSpecular");
	m_parameters[U_MATERIAL_SHININESS] = glGetUniformLocation(m_programID, "material.kShininess");
	m_parameters[U_LIGHT0_POSITION] = glGetUniformLocation(m_programID, "lights[0].position_cameraspace");
	m_parameters[U_LIGHT0_COLOR] = glGetUniformLocation(m_programID, "lights[0].color");
	m_parameters[U_LIGHT0_POWER] = glGetUniformLocation(m_programID, "lights[0].power");
	m_parameters[U_LIGHT0_KC] = glGetUniformLocation(m_programID, "lights[0].kC");
	m_parameters[U_LIGHT0_KL] = glGetUniformLocation(m_programID, "lights[0].kL");
	m_parameters[U_LIGHT0_KQ] = glGetUniformLocation(m_programID, "lights[0].kQ");


	m_parameters[U_NUMLIGHTS] = glGetUniformLocation(m_programID, "numLights");
	m_parameters[U_LIGHT0_TYPE] = glGetUniformLocation(m_programID, "lights[0].type");
	m_parameters[U_LIGHT0_SPOTDIRECTION] = glGetUniformLocation(m_programID, "lights[0].spotDirection");
	m_parameters[U_LIGHT0_COSCUTOFF] = glGetUniformLocation(m_programID, "lights[0].cosCutoff");
	m_parameters[U_LIGHT0_COSINNER] = glGetUniformLocation(m_programID, "lights[0].cosInner");
	m_parameters[U_LIGHT0_EXPONENT] = glGetUniformLocation(m_programID, "lights[0].exponent");


	m_parameters[U_MVP] = glGetUniformLocation(m_programID, "MVP");

	glUseProgram(m_programID);

	glUniform1i(m_parameters[U_NUMLIGHTS], 1);

	// Enable depth test
	glEnable(GL_DEPTH_TEST);

	light[0].type = Light::LIGHT_SPOT;
	light[0].position.Set(0, 20, 0);
	light[0].color.Set(1, 1, 1);
	light[0].power = 1;
	light[0].kC = 1.f;
	light[0].kL = 0.01f;
	light[0].kQ = 0.001f;
	light[0].cosCutoff = cos(Math::DegreeToRadian(45));
	light[0].cosInner = cos(Math::DegreeToRadian(30));
	light[0].exponent = 3.f;
	light[0].spotDirection.Set(0.f, 1.f, 0.f);

	//Light 1
	light[1].type = Light::LIGHT_SPOT;
	light[1].position.Set(0, -45, 0);
	light[1].color.Set(1, 1, 1);
	light[1].power = 1;
	light[1].kC = 1.f;
	light[1].kL = 0.01f;
	light[1].kQ = 0.001f;
	light[1].cosCutoff = cos(Math::DegreeToRadian(45));
	light[1].cosInner = cos(Math::DegreeToRadian(30));
	light[1].exponent = 3.f;
	light[1].spotDirection.Set(0.f, 1.f, 0.f);

	for (int i = 0; i < 3; i++)
	{
		glUniform1i(m_parameters[U_LIGHT0_TYPE+i], light[i].type);
		glUniform3fv(m_parameters[U_LIGHT0_COLOR+i], 1, &light[i].color.r);
		glUniform1f(m_parameters[U_LIGHT0_POWER+i], light[i].power);
		glUniform1f(m_parameters[U_LIGHT0_KC+i], light[i].kC);
		glUniform1f(m_parameters[U_LIGHT0_KL+i], light[i].kL);
		glUniform1f(m_parameters[U_LIGHT0_KQ+i], light[i].kQ);
		glUniform1f(m_parameters[U_LIGHT0_COSCUTOFF+i], light[i].cosCutoff);
		glUniform1f(m_parameters[U_LIGHT0_COSINNER+i], light[i].cosInner);
		glUniform1f(m_parameters[U_LIGHT0_EXPONENT+i], light[i].exponent);
	}

	for (int i = 0; i < NUM_GEOMETRY; ++i)
	{
		meshList[i] = NULL;
	}

	meshList[GEO_AXES] = MeshBuilder::GenerateAxes("reference", 1000, 1000, 1000);
	meshList[GEO_SPHERE1] = MeshBuilder::GenerateSphere("sphere", Color(1, 0, 0), 18, 36, 1);

	meshList[GEO_LIGHTBALL] = MeshBuilder::GenerateSphere("sphere", Color(1, 1, 1), 18, 36, 1);

	meshList[GEO_LEFT] = MeshBuilder::GenerateQuad("left", Color(1, 1, 1), 1.0f, 1.0f);
	meshList[GEO_LEFT]->textureID = LoadTGA("Image//left.tga");

	meshList[GEO_RIGHT] = MeshBuilder::GenerateQuad("right", Color(1, 1, 1), 1.0f, 1.0f);
	meshList[GEO_RIGHT]->textureID = LoadTGA("Image//right.tga");

	meshList[GEO_TOP] = MeshBuilder::GenerateQuad("top", Color(1, 1, 1), 1.0f, 1.0f);
	meshList[GEO_TOP]->textureID = LoadTGA("Image//top.tga");

	meshList[GEO_BOTTOM] = MeshBuilder::GenerateQuad("bottom", Color(1, 1, 1), 1.0f, 1.0f);
	meshList[GEO_BOTTOM]->textureID = LoadTGA("Image//bottom.tga");

	meshList[GEO_FRONT] = MeshBuilder::GenerateQuad("front", Color(1, 1, 1), 1.0f, 1.0f);
	meshList[GEO_FRONT]->textureID = LoadTGA("Image//front.tga");

	meshList[GEO_BACK] = MeshBuilder::GenerateQuad("back", Color(1, 1, 1), 1.0f, 1.0f);
	meshList[GEO_BACK]->textureID = LoadTGA("Image//back.tga");

	meshList[GEO_GUNCABINET] = MeshBuilder::GenerateOBJ("modelgunCabinet", "OBJ//gunCabinet.obj");
	meshList[GEO_GUNCABINET]->textureID = LoadTGA("Image//gunCabinet.tga");

	meshList[GEO_VENDORTABLE] = MeshBuilder::GenerateOBJ("modelVendor", "OBJ//vendorTable.obj");
	meshList[GEO_VENDORTABLE]->textureID = LoadTGA("Image//vendorTable.tga");

	meshList[GEO_LAMP] = MeshBuilder::GenerateOBJ("modelLamp", "OBJ//lamp.obj");
	meshList[GEO_LAMP]->textureID = LoadTGA("Image//lamp.tga");

	meshList[GEO_REPAIR] = MeshBuilder::GenerateOBJ("modelRepairTable", "OBJ//gunStation.obj");
	meshList[GEO_REPAIR]->textureID = LoadTGA("Image//gunStation.tga");

	meshList[GEO_RANGE] = MeshBuilder::GenerateOBJ("modelShootingRange", "OBJ//shootingRange.obj");
	meshList[GEO_RANGE]->textureID = LoadTGA("Image//shootingRange.tga");

	meshList[GEO_TARGET] = MeshBuilder::GenerateOBJ("modelRangeTarget", "OBJ//target.obj");
	meshList[GEO_TARGET]->textureID = LoadTGA("Image//target.tga");

	meshList[GEO_TARGETRANGE] = MeshBuilder::GenerateOBJ("modelRangeTarget", "OBJ//targetRange.obj");
	meshList[GEO_TARGETRANGE]->textureID = LoadTGA("Image//targetRange.tga");

	// Get a handle for our "textColor" uniform
	m_parameters[U_TEXT_ENABLED] = glGetUniformLocation(m_programID, "textEnabled");
	m_parameters[U_TEXT_COLOR] = glGetUniformLocation(m_programID, "textColor");
	meshList[GEO_TEXT] = MeshBuilder::GenerateText("text", 16, 16);
	meshList[GEO_TEXT]->textureID = LoadTGA("Image//calibri.tga");
	meshList[GEO_FPSCOUNTER] = MeshBuilder::GenerateText("FPS", 16, 16);
	meshList[GEO_FPSCOUNTER]->textureID = LoadTGA("Image//calibri.tga");
	meshList[GEO_GUNCABINETINTERACTION] = MeshBuilder::GenerateText("FPS", 16, 16);
	meshList[GEO_GUNCABINETINTERACTION]->textureID = LoadTGA("Image//calibri.tga");
	meshList[GEO_GUNSTATIONINTERACTION] = MeshBuilder::GenerateText("FPS", 16, 16);
	meshList[GEO_GUNSTATIONINTERACTION]->textureID = LoadTGA("Image//calibri.tga");
	meshList[GEO_GUNVENDORINTERACTION] = MeshBuilder::GenerateText("FPS", 16, 16);
	meshList[GEO_GUNVENDORINTERACTION]->textureID = LoadTGA("Image//calibri.tga");
	meshList[GEO_GUNRANGEINTERACTION] = MeshBuilder::GenerateText("FPS", 16, 16);
	meshList[GEO_GUNRANGEINTERACTION]->textureID = LoadTGA("Image//calibri.tga");
}

bool isPointinBox(Vector3 position, Length box)
{
	return (position.x >= box.minX && position.x <= box.maxX) &&
		(position.y >= box.minY && position.y <= box.maxY) &&
		(position.z >= box.minZ && position.z <= box.maxZ);
}

void SceneText::boundsCheck(double dt)
{
	Vector3 view = camera.target - camera.position;
	Vector3 right = view.Cross(camera.up);

	static const float CAMERA_SPEED = 50.f;
	static const float MOVEMENT_SPEED = 3.0f;
	Length skybox = Length(Vector3(0, -20, 0), 100, 29, 50);
	Length gunCabinet = Length(Vector3(-24, -27, -43), 40, 25, 8);
	Length vendorTable = Length(Vector3(-73, -45, 38), 25, 10, 15);
	Length lamp1 = Length(Vector3(0, 3.65, 0 ),3, 4.84, 3);
	Length gunStation = Length(Vector3(-90, -45,-25), 15, 15, 25);
	Length gunRange = Length(Vector3(70, -45, 0), 50, 40, 50);

	bool collided = isPointinBox(camera.position, skybox);
	bool collideProp = isPointinBox(camera.position, gunCabinet);
	bool collideVendor = isPointinBox(camera.position, vendorTable);
	bool collideLamp1 = isPointinBox(camera.position, lamp1);
	bool collideStation = isPointinBox(camera.position, gunStation);
	bool collideRange = isPointinBox(camera.position, gunRange);

	//std::cout << camera.position << std::endl;
	//std::cout << "Collison";
	if (collided == false)
	{
		collidedSkybox();
	}
	else if (collideProp)
	{
		collidedProp();
	}
	else if (collideVendor)
	{
		collidedProp();
	}
	else if (collideLamp1)
	{
		collidedProp();
	}
	else if (collideStation)
	{
		collidedProp();
	}
	else if (collideRange)
	{
		collidedProp();
	}
}

void SceneText::interactionCheck(double dt)
{
	Vector3 view = camera.target - camera.position;
	Vector3 right = view.Cross(camera.up);

	Length gunCabinet = Length(Vector3(-24, -27, -43), 40, 25, 15);
	Length vendorTable = Length(Vector3(-73, -45, 38), 30, 40, 20);
	Length gunStation = Length(Vector3(-90, -45, -25), 15, 40, 25);
	Length gunRange = Length(Vector3(70, -45, 0), 53, 40, 53);

	bool cabinetInteraction = isPointinBox(camera.position, gunCabinet);
	bool vendorInteraction = isPointinBox(camera.position, vendorTable);
	bool stationInteraction = isPointinBox(camera.position, gunStation);
	bool rangeInteraction = isPointinBox(camera.position, gunRange);

	if (cabinetInteraction == true)
	{
		gunCabinetCheck = true;
	}
	else if (vendorInteraction == true)
	{
		gunVendorCheck = true;
	}
	else if (stationInteraction == true)
	{
		gunStationCheck = true;
	}
	else if (rangeInteraction == true)
	{
		gunRangeCheck = true;
	}
	else
	{
		gunStationInteraction = false;
		gunStationCheck = false;

		gunCabinetInteraction = false;
		gunCabinetCheck = false;

		gunVendorInteraction = false;
		gunVendorCheck = false;

		gunRangeInteraction = false;
		gunRangeCheck = false;
	}
}



void SceneText::Update(double dt)
{
	currentFPS = (1 / dt);

	static const float LSPEED = 10.0f;
	if (Application::IsKeyPressed('1'))
	{
		glEnable(GL_CULL_FACE);
	}
	if (Application::IsKeyPressed('2'))
	{
		glDisable(GL_CULL_FACE);
	}
	if (Application::IsKeyPressed('3'))
	{
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	}
	if (Application::IsKeyPressed('4'))
	{
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	}

	if (Application::IsKeyPressed('I'))
		light[0].position.z -= (float)(LSPEED * dt);
	if (Application::IsKeyPressed('K'))
		light[0].position.z += (float)(LSPEED * dt);
	if (Application::IsKeyPressed('J'))
		light[0].position.x -= (float)(LSPEED * dt);
	if (Application::IsKeyPressed('L'))
		light[0].position.x += (float)(LSPEED * dt);
	if (Application::IsKeyPressed('O'))
		light[0].position.y -= (float)(LSPEED * dt);
	if (Application::IsKeyPressed('P'))
		light[0].position.y += (float)(LSPEED * dt);

	if (Application::IsKeyPressed('Z'))
	{
		light[0].type = Light::LIGHT_POINT;
		glUniform1i(m_parameters[U_LIGHT0_TYPE], light[0].type);
		//to do: switch light type to POINT and pass the information to shader
	}
	else if (Application::IsKeyPressed('X'))
	{
		light[0].type = Light::LIGHT_DIRECTIONAL;
		glUniform1i(m_parameters[U_LIGHT0_TYPE], light[0].type);
		//to do: switch light type to DIRECTIONAL and pass the information to shader
	}
	else if (Application::IsKeyPressed('C'))
	{
		light[0].type = Light::LIGHT_SPOT;
		glUniform1i(m_parameters[U_LIGHT0_TYPE], light[0].type);
		//to do: switch light type to SPOT and pass the information to shader
	}
		
	camera.Update(dt);
	boundsCheck(dt);
	interactionCheck(dt);

	if ((gunCabinetCheck == true) && (Application::IsKeyPressed('E')))
	{
		gunCabinetInteraction = true;
	}
	else if ((gunStationCheck == true) && (Application::IsKeyPressed('E')))
	{
		gunStationInteraction = true;
	}
	else if ((gunVendorCheck == true) && (Application::IsKeyPressed('E')))
	{
		gunVendorInteraction = true;
	}
	else if ((gunRangeCheck == true) && (Application::IsKeyPressed('E')))
	{
		gunRangeInteraction = true;
	}

	float translateAmt = 10;
	float translateMax = 40;
	translateZ += (float)(translateAmt * dt);
	if (translateZ > translateMax)
	{
		translateZ = 0;
	}
}

void SceneText::collidedSkybox()
{
	Vector3 view = camera.target - camera.position;
	Vector3 right = view.Cross(camera.up);

	static const float CAMERA_SPEED = 3.f;
	static const float MOVEMENT_SPEED = 3.f;

	if (Application::IsKeyPressed('D'))
	{
		camera.position = camera.position - right * MOVEMENT_SPEED;
		camera.target = camera.position + view;
		if (Application::IsKeyPressed('W'))
		{
			camera.position = camera.position - view * MOVEMENT_SPEED;
			camera.target = camera.position + view;
		}

		if (Application::IsKeyPressed('S'))
		{
			camera.position = camera.position + view * MOVEMENT_SPEED;
			camera.target = camera.position + view;
		}

		else if (Application::IsKeyPressed('A'))
		{
			camera.position = camera.position + right * MOVEMENT_SPEED;
			camera.target = camera.position + view;
		}
	}
	else if (Application::IsKeyPressed('A'))
	{
		camera.position = camera.position + right * MOVEMENT_SPEED;
		camera.target = camera.position + view;
		if (Application::IsKeyPressed('W'))
		{
			camera.position = camera.position - view * MOVEMENT_SPEED;
			camera.target = camera.position + view;
		}

		if (Application::IsKeyPressed('S'))
		{
			camera.position = camera.position + view * MOVEMENT_SPEED;
			camera.target = camera.position + view;
		}

		else if (Application::IsKeyPressed('D'))
		{
			camera.position = camera.position - right * MOVEMENT_SPEED;
			camera.target = camera.position + view;
		}
	}
	else if (Application::IsKeyPressed('S'))
	{
		camera.position = camera.position + view * MOVEMENT_SPEED;
		camera.target = camera.position + view;
		if (Application::IsKeyPressed('W'))
		{
			camera.position = camera.position - view * MOVEMENT_SPEED;
			camera.target = camera.position + view;
		}

		else if (Application::IsKeyPressed('A'))
		{
			camera.position = camera.position + right * MOVEMENT_SPEED;
			camera.target = camera.position + view;
		}

		else if (Application::IsKeyPressed('D'))
		{
			camera.position = camera.position - right * MOVEMENT_SPEED;
			camera.target = camera.position + view;
		}
	}
	else if (Application::IsKeyPressed('W'))
	{
		camera.position = camera.position - view * MOVEMENT_SPEED;
		camera.target = camera.position + view;
		if (Application::IsKeyPressed('D'))
		{
			camera.position = camera.position - right * MOVEMENT_SPEED;
			camera.target = camera.position + view;
		}

		if (Application::IsKeyPressed('S'))
		{
			camera.position = camera.position + view * MOVEMENT_SPEED;
			camera.target = camera.position + view;
		}

		else if (Application::IsKeyPressed('A'))
		{
			camera.position = camera.position + right * MOVEMENT_SPEED;
			camera.target = camera.position + view;
		}
	}
}

void SceneText::collidedProp()
{
	Vector3 view = camera.target - camera.position;
	Vector3 right = view.Cross(camera.up);

	static const float CAMERA_SPEED = 3.f;
	static const float MOVEMENT_SPEED = 3.f;

	if (Application::IsKeyPressed('D'))
	{
		camera.position = camera.position - right * MOVEMENT_SPEED;
		camera.target = camera.position + view;
		if (Application::IsKeyPressed('W'))
		{
			camera.position = camera.position - view * MOVEMENT_SPEED;
			camera.target = camera.position + view;
		}

		if (Application::IsKeyPressed('S'))
		{
			camera.position = camera.position + view * MOVEMENT_SPEED;
			camera.target = camera.position + view;
		}

		else if (Application::IsKeyPressed('A'))
		{
			camera.position = camera.position + right * MOVEMENT_SPEED;
			camera.target = camera.position + view;
		}
	}
	else if (Application::IsKeyPressed('A'))
	{
		camera.position = camera.position + right * MOVEMENT_SPEED;
		camera.target = camera.position + view;
		if (Application::IsKeyPressed('W'))
		{
			camera.position = camera.position - view * MOVEMENT_SPEED;
			camera.target = camera.position + view;
		}

		if (Application::IsKeyPressed('S'))
		{
			camera.position = camera.position + view * MOVEMENT_SPEED;
			camera.target = camera.position + view;
		}

		else if (Application::IsKeyPressed('D'))
		{
			camera.position = camera.position - right * MOVEMENT_SPEED;
			camera.target = camera.position + view;
		}
	}
	else if (Application::IsKeyPressed('S'))
	{
		camera.position = camera.position + view * MOVEMENT_SPEED;
		camera.target = camera.position + view;
		if (Application::IsKeyPressed('W'))
		{
			camera.position = camera.position - view * MOVEMENT_SPEED;
			camera.target = camera.position + view;
		}

		else if (Application::IsKeyPressed('A'))
		{
			camera.position = camera.position + right * MOVEMENT_SPEED;
			camera.target = camera.position + view;
		}

		else if (Application::IsKeyPressed('D'))
		{
			camera.position = camera.position - right * MOVEMENT_SPEED;
			camera.target = camera.position + view;
		}
	}
	else if (Application::IsKeyPressed('W'))
	{
		camera.position = camera.position - view * MOVEMENT_SPEED;
		camera.target = camera.position + view;
		if (Application::IsKeyPressed('D'))
		{
			camera.position = camera.position - right * MOVEMENT_SPEED;
			camera.target = camera.position + view;
		}

		if (Application::IsKeyPressed('S'))
		{
			camera.position = camera.position + view * MOVEMENT_SPEED;
			camera.target = camera.position + view;
		}

		else if (Application::IsKeyPressed('A'))
		{
			camera.position = camera.position + right * MOVEMENT_SPEED;
			camera.target = camera.position + view;
		}
	}
}

void SceneText::Render()
{
	//Clear color & depth buffer every frame
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	viewStack.LoadIdentity();
	viewStack.LookAt(camera.position.x, camera.position.y, camera.position.z, camera.target.x, camera.target.y, camera.target.z, camera.up.x, camera.up.y, camera.up.z);
	modelStack.LoadIdentity();

	//Light 0
	if (light[0].type == Light::LIGHT_DIRECTIONAL)
	{
		Vector3 lightDir(light[0].position.x, light[0].position.y, light[0].position.z);
		Vector3 lightDirection_cameraspace = viewStack.Top() * lightDir;
		glUniform3fv(m_parameters[U_LIGHT0_POSITION], 1, &lightDirection_cameraspace.x);
	}
	else if (light[0].type == Light::LIGHT_SPOT)
	{
		Position lightPosition_cameraspace = viewStack.Top() * light[0].position;
		glUniform3fv(m_parameters[U_LIGHT0_POSITION], 1, &lightPosition_cameraspace.x);
		Vector3 spotDirection_cameraspace = viewStack.Top() * light[0].spotDirection;
		glUniform3fv(m_parameters[U_LIGHT0_SPOTDIRECTION], 1, &spotDirection_cameraspace.x);
	}
	else
	{
		Position lightPosition_cameraspace = viewStack.Top() * light[0].position;
		glUniform3fv(m_parameters[U_LIGHT0_POSITION], 1, &lightPosition_cameraspace.x);
	}

	//Light 1
	if (light[1].type == Light::LIGHT_DIRECTIONAL)
	{
		Vector3 lightDir(light[1].position.x, light[1].position.y, light[1].position.z);
		Vector3 lightDirection_cameraspace = viewStack.Top() * lightDir;
		glUniform3fv(m_parameters[U_LIGHTSAYOURI_POSITION], 1, &lightDirection_cameraspace.x);
	}
	else if (light[1].type == Light::LIGHT_SPOT)
	{
		Position lightPosition_cameraspace = viewStack.Top() * light[1].position;
		glUniform3fv(m_parameters[U_LIGHTSAYOURI_POSITION], 1, &lightPosition_cameraspace.x);
		Vector3 spotDirection_cameraspace = viewStack.Top() * light[1].spotDirection;
		glUniform3fv(m_parameters[U_LIGHTSAYOURI_SPOTDIRECTION], 1, &spotDirection_cameraspace.x);
	}
	else
	{
		Position lightPosition_cameraspace = viewStack.Top() * light[1].position;
		glUniform3fv(m_parameters[U_LIGHTSAYOURI_POSITION], 1, &lightPosition_cameraspace.x);
	}
	//SKYBOX
	RenderSkybox();


	//RENDER MODELS
	// Right cabinet
	modelStack.PushMatrix();
	modelStack.Scale(3, 3, 3);
	modelStack.Translate(-3, -13, -14);
	RenderMesh(meshList[GEO_GUNCABINET], false);
	modelStack.PopMatrix();
	 // Middle Cabinet
	modelStack.PushMatrix();
	modelStack.Scale(3, 3, 3);
	modelStack.Translate(-11, -13, -14);
	RenderMesh(meshList[GEO_GUNCABINET], false);
	modelStack.PopMatrix();
	//Left Cabinet
	modelStack.PushMatrix();
	modelStack.Scale(3, 3, 3);
	modelStack.Translate(-19, -13, -14);
	RenderMesh(meshList[GEO_GUNCABINET], false);
	modelStack.PopMatrix();

	modelStack.PushMatrix();
	modelStack.Scale(3, 3, 3);
	modelStack.Translate(-18, -17, 12);
	modelStack.Rotate(90, 0, 1, 0);
	RenderMesh(meshList[GEO_VENDORTABLE], false);
	modelStack.PopMatrix();

	modelStack.PushMatrix();
	modelStack.Scale(3, 3, 3);
	modelStack.Translate(0, -6, 0);
	RenderMesh(meshList[GEO_LAMP], false);
	modelStack.PopMatrix();

	modelStack.PushMatrix();
	modelStack.Scale(3, 3, 3);
	modelStack.Translate(-32, -17, -4);
	RenderMesh(meshList[GEO_REPAIR], false);
	modelStack.PopMatrix();

	//reuse of model to cover gaps
	modelStack.PushMatrix();
	modelStack.Scale(3, 3, 3);
	modelStack.Rotate(-90, 0, 1, 0);
	modelStack.Translate(5, -17, -7);
	RenderMesh(meshList[GEO_RANGE], false);
	modelStack.PopMatrix();

	modelStack.PushMatrix();
	modelStack.Scale(3, 3, 3);
	modelStack.Rotate(-90, 0, 1, 0);
	modelStack.Translate(-15, -17, -7);
	RenderMesh(meshList[GEO_RANGE], false);
	modelStack.PopMatrix();

	modelStack.PushMatrix();
	modelStack.Scale(3, 3, 3);
	modelStack.Rotate(-90, 0, 1, 0);
	modelStack.Translate(25, -17, -7);
	RenderMesh(meshList[GEO_RANGE], false);
	modelStack.PopMatrix();

	modelStack.PushMatrix();
	modelStack.Scale(3, 3, 3);
	modelStack.Rotate(90, 0, 1, 0);
	modelStack.Translate(20, -9, 30);
	modelStack.Translate(-translateZ, 0, 0);
	RenderMesh(meshList[GEO_TARGET], false);
	modelStack.PopMatrix();

	modelStack.PushMatrix();
	modelStack.Scale(3, 3, 3);
	modelStack.Rotate(-90, 0, 1, 0);
	modelStack.Translate(-10, -13, -25);
	RenderMesh(meshList[GEO_TARGETRANGE], false);
	modelStack.PopMatrix();

	modelStack.PushMatrix();
	modelStack.Scale(3, 3, 3);
	modelStack.Rotate(90, 0, 1, 0);
	modelStack.Translate(-10, -13, 25);
	RenderMesh(meshList[GEO_TARGETRANGE], false);
	modelStack.PopMatrix();

	modelStack.PushMatrix();
	modelStack.Scale(3, 3, 3);
	modelStack.Translate(30, -13, 0);
	modelStack.Rotate(90, 0, 1, 0);
	modelStack.Rotate(180, 0, 0, 1);
	RenderMesh(meshList[GEO_TARGETRANGE], false);
	modelStack.PopMatrix();

	//TEXT RENDER VVVVV
	//This segment is just for refrence
	//modelStack.PushMatrix();
	//RenderText(meshList[GEO_TEXT], "Yuri > Every Doki", Color(0, 1, 0));
	//RenderTextOnScreen(meshList[GEO_TEXT], FPS, Color(0, 1, 0), 1, 1, 1);
	//modelStack.PopMatrix();


	modelStack.PushMatrix();
	std::stringstream fpsDisplay;
	fpsDisplay << currentFPS;
	std::string fps = fpsDisplay.str();
	RenderTextOnScreen(meshList[GEO_FPSCOUNTER], "FPS :" + fps , Color(1, 0, 0), 3, 0.7, 1);
	modelStack.PopMatrix();

	if (gunCabinetInteraction == true)
	{
		modelStack.PushMatrix();
		RenderTextOnScreen(meshList[GEO_GUNCABINETINTERACTION], "A firearm storage cabinet", Color(0, 0, 0), 3, 1.6, 15);
		modelStack.PopMatrix();
		//std::cout << "Cabinet";
	}

	if (gunStationInteraction == true)
	{
		modelStack.PushMatrix();
		RenderTextOnScreen(meshList[GEO_GUNSTATIONINTERACTION], "A gun repair station", Color(0, 0, 0), 3, 5, 15);
		modelStack.PopMatrix();
		//std::cout << "Station";
	}

	if (gunVendorInteraction == true)
	{
		modelStack.PushMatrix();
		RenderTextOnScreen(meshList[GEO_GUNVENDORINTERACTION], "All items are overpriced", Color(0, 0, 0), 3, 1.6, 15);
		modelStack.PopMatrix();
		//std::cout << "Vendor";
	}

	if (gunRangeInteraction == true)
	{
		modelStack.PushMatrix();
		RenderTextOnScreen(meshList[GEO_GUNRANGEINTERACTION], "A firearm shoting range", Color(0, 0, 0), 3, 1.6, 15);
		modelStack.PopMatrix();
		//std::cout << "Range";
	}
}

void SceneText::RenderMesh(Mesh *mesh, bool enableLight)
{
	Mtx44 MVP, modelView, modelView_inverse_transpose;

	MVP = projectionStack.Top() * viewStack.Top() * modelStack.Top();
	glUniformMatrix4fv(m_parameters[U_MVP], 1, GL_FALSE, &MVP.a[0]);
	modelView = viewStack.Top() * modelStack.Top();
	glUniformMatrix4fv(m_parameters[U_MODELVIEW], 1, GL_FALSE, &modelView.a[0]);
	if (enableLight)
	{
		glUniform1i(m_parameters[U_LIGHTENABLED], 1);
		modelView_inverse_transpose = modelView.GetInverse().GetTranspose();
		glUniformMatrix4fv(m_parameters[U_MODELVIEW_INVERSE_TRANSPOSE], 1, GL_FALSE, &modelView_inverse_transpose.a[0]);

		//load material
		glUniform3fv(m_parameters[U_MATERIAL_AMBIENT], 1, &mesh->material.kAmbient.r);
		glUniform3fv(m_parameters[U_MATERIAL_DIFFUSE], 1, &mesh->material.kDiffuse.r);
		glUniform3fv(m_parameters[U_MATERIAL_SPECULAR], 1, &mesh->material.kSpecular.r);
		glUniform1f(m_parameters[U_MATERIAL_SHININESS], mesh->material.kShininess);
	}
	else
	{
		glUniform1i(m_parameters[U_LIGHTENABLED], 0);
	}

	if (mesh->textureID > 0)
	{
		glUniform1i(m_parameters[U_COLOR_TEXTURE_ENABLED], 1);
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, mesh->textureID);
		glUniform1i(m_parameters[U_COLOR_TEXTURE], 0);
	}
	else
	{
		glUniform1i(m_parameters[U_COLOR_TEXTURE_ENABLED], 0);
	}
	mesh->Render(); //this line should only be called once 
	if (mesh->textureID > 0)
	{
		glBindTexture(GL_TEXTURE_2D, 0);
	}



}

void SceneText::RenderSkybox()
{

	modelStack.PushMatrix();
	modelStack.Scale(100, 100, 100);
	modelStack.Translate(-1, 0, 0);
	modelStack.Rotate(90, 0, 1, 0);
	RenderMesh(meshList[GEO_LEFT], false);
	modelStack.PopMatrix();

	modelStack.PushMatrix();
	modelStack.Scale(100, 100, 100);
	modelStack.Translate(1, 0, 0);
	modelStack.Rotate(-90, 0, 1, 0);
	RenderMesh(meshList[GEO_RIGHT], false);
	modelStack.PopMatrix();

	modelStack.PushMatrix();
	modelStack.Scale(200, 100, 100);
	modelStack.Translate(0, 0.1, 0);
	modelStack.Rotate(90, 1, 0, 0);
	modelStack.Rotate(90, 0, 0, 1);
	RenderMesh(meshList[GEO_TOP], false);
	modelStack.PopMatrix();

	modelStack.PushMatrix();
	modelStack.Scale(200, 100, 100);
	modelStack.Translate(0, -0.495, 0);
	modelStack.Rotate(-90, 1, 0, 0);
	RenderMesh(meshList[GEO_BOTTOM], false);
	modelStack.PopMatrix();

	modelStack.PushMatrix();
	modelStack.Scale(200, 100, 100);
	modelStack.Translate(0, 0, -0.495);
	RenderMesh(meshList[GEO_FRONT], false);
	modelStack.PopMatrix();

	modelStack.PushMatrix();
	modelStack.Scale(200, 100, 100);
	modelStack.Translate(0, 0, 0.495);
	modelStack.Rotate(180, 0, 1, 0);
	RenderMesh(meshList[GEO_BACK], false);
	modelStack.PopMatrix();



}

void SceneText::RenderText(Mesh* mesh, std::string text, Color color)
{
	if (!mesh || mesh->textureID <= 0) //Proper error check
		return;

	glDisable(GL_DEPTH_TEST);
	glUniform1i(m_parameters[U_TEXT_ENABLED], 1);
	glUniform3fv(m_parameters[U_TEXT_COLOR], 1, &color.r);
	glUniform1i(m_parameters[U_LIGHTENABLED], 0);
	glUniform1i(m_parameters[U_COLOR_TEXTURE_ENABLED], 1);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, mesh->textureID);
	glUniform1i(m_parameters[U_COLOR_TEXTURE], 0);
	for (unsigned i = 0; i < text.length(); ++i)
	{
		Mtx44 characterSpacing;
		characterSpacing.SetToTranslation(i * 1.0f, 0, 0); //1.0f is the spacing of each character, you may change this value
		Mtx44 MVP = projectionStack.Top() * viewStack.Top() * modelStack.Top() * characterSpacing;
		glUniformMatrix4fv(m_parameters[U_MVP], 1, GL_FALSE, &MVP.a[0]);

		mesh->Render((unsigned)text[i] * 6, 6);
	}
	glBindTexture(GL_TEXTURE_2D, 0);
	glUniform1i(m_parameters[U_TEXT_ENABLED], 0);
	glEnable(GL_DEPTH_TEST);
}

void SceneText::RenderTextOnScreen(Mesh* mesh, std::string text, Color color, float size, float x, float y)
{
	if (!mesh || mesh->textureID <= 0) //Proper error check
		return;

	glDisable(GL_DEPTH_TEST);
	Mtx44 ortho;
	ortho.SetToOrtho(0, 80, 0, 60, -10, 10); //size of screen UI
	projectionStack.PushMatrix();
	projectionStack.LoadMatrix(ortho);
	viewStack.PushMatrix();
	viewStack.LoadIdentity(); //No need camera for ortho mode
	modelStack.PushMatrix();
	modelStack.LoadIdentity(); //Reset modelStack
	modelStack.Scale(size, size, size);
	modelStack.Translate(x, y, 0);

	glUniform1i(m_parameters[U_TEXT_ENABLED], 1);
	glUniform3fv(m_parameters[U_TEXT_COLOR], 1, &color.r);
	glUniform1i(m_parameters[U_LIGHTENABLED], 0);
	glUniform1i(m_parameters[U_COLOR_TEXTURE_ENABLED], 1);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, mesh->textureID);
	glUniform1i(m_parameters[U_COLOR_TEXTURE], 0);
	for (unsigned i = 0; i < text.length(); ++i)
	{
		Mtx44 characterSpacing;
		characterSpacing.SetToTranslation(i * 1.0f, 0, 0); //1.0f is the spacing of each character, you may change this value
		Mtx44 MVP = projectionStack.Top() * viewStack.Top() * modelStack.Top() * characterSpacing;
		glUniformMatrix4fv(m_parameters[U_MVP], 1, GL_FALSE, &MVP.a[0]);

		mesh->Render((unsigned)text[i] * 6, 6);
	}
	glBindTexture(GL_TEXTURE_2D, 0);
	glUniform1i(m_parameters[U_TEXT_ENABLED], 0);
	projectionStack.PopMatrix();
	viewStack.PopMatrix();
	modelStack.PopMatrix();
	glEnable(GL_DEPTH_TEST);


}

void SceneText::Exit()
{
	// Cleanup VBO here
	for (int i = 0; i < NUM_GEOMETRY; ++i)
	{
		if (meshList[i] != NULL)
		{
			delete meshList[i];
		}
		meshList[i] = NULL;
	}

	glDeleteVertexArrays(1, &m_vertexArrayID);
	glDeleteProgram(m_programID);

}